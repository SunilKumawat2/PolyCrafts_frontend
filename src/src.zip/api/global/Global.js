import axios from "axios";
import { API_BASE_URL } from "../../config/Config";

// <----------------  Register Api's --------------->
export const User_Contact_Requests = async (userData) => {
    try {
        const response = await axios.post(`${API_BASE_URL}/user/contact-requests`, userData);
        return response;
    } catch (error) {
        throw error.response || error;
    }
};