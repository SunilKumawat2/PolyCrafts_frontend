import React from 'react'
import { Route, Routes } from 'react-router-dom'
import Home_before_login from '../components/pages/home/Home_before_login'
import Home from '../components/pages/home/Home'
import User_Profile from '../components/pages/user_profile/User_Profile'
import FAQ from '../components/pages/faq/FAQ'
import Choose_Video from '../components/pages/choose_video/Choose_Video'
import Upload_Products from '../components/pages/upload_products/Upload_Products'
import About from '../components/pages/about/About'
import Upload_3d_Modals from '../components/pages/upload_modals/Upload_3d_Modals'
import Upload_Modals from '../components/pages/upload_modals/Upload_Modals'
import Pricing from '../components/pages/pricing/Pricing'
import My_Orders from '../components/pages/my_orders/My_Orders'
import Change_Password from '../components/pages/change_password/Change_Password'
import Admin_Dashboard from '../components/pages/admin/admin_dashboard/Admin_Dashboard'


const AllRoutes = () => {

  let base_url = process.env.REACT_APP_BASE_URL;
  const get_user_token = localStorage.getItem("polycarft_user_token")

  return (
    <div>
      <Routes>
        {
          get_user_token ? <Route path={`${base_url}`} element={<Home />} /> :
            <Route path={`${base_url}`} element={<Home_before_login />} />
        }

        <Route path={`${base_url}user-profile`} element={<User_Profile />} />
        <Route path={`${base_url}about`} element={<About />} />
        <Route path={`${base_url}pricing`} element={<Pricing />} />
        <Route path={`${base_url}faq`} element={<FAQ />} />
        <Route path={`${base_url}choose-video`} element={<Choose_Video />} />
        <Route path={`${base_url}upload-products`} element={<Upload_Products />} />
        <Route path={`${base_url}upload-3d-modal`} element={<Upload_3d_Modals />} />
        <Route path={`${base_url}upload-modal`} element={<Upload_Modals />} />
        <Route path={`${base_url}my-orders`} element={<My_Orders />} />
        <Route path={`${base_url}change-password`} element={<Change_Password />} />
        <Route path={`${base_url}admin-dashboard`} element={<Admin_Dashboard />} />
      </Routes>
    </div>
  )
}

export default AllRoutes
