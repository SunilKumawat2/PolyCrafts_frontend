import React from 'react'
import { Link } from 'react-router-dom'
import Header from '../../common/header/Header'
import Footer from '../../common/footer/Footer'
import UplaodIcon from "../../../assets/images/upload-icon.svg";
import PlusIcon from "../../../assets/images/plus-icon.svg";

const Upload_Modals = () => {

    let base_url = process.env.REACT_APP_BASE_URL;




    return (
        <>
            <main className="upload-modals-page">
                {/* ===== HEADER ===== */}
                <Header />


                {/* ========== My Profile start ======= */}
                <section className='upload-modal-sec px-85'>
                    <div className="container-fluid">
                        <div className='upload-modal-row row'>
                            <div className="col-modal-form">
                                <div className='headings'>
                                    <h2>Upload products</h2>
                                    <p>Upload and attach files to this project.</p>
                                </div>
                                <div className='video-info'>
                                    <div className='head'>
                                        <div className='name-outer'>
                                            <div className='name'>
                                                <h6 className='info-title'>Video Name</h6>
                                                <p>6763</p>
                                            </div>
                                        </div>
                                        <div className='credits-dlt'>
                                            <div className='aspect-div'>
                                                <h6 className='info-title'>Aspect ratio selected</h6>
                                                <ul>
                                                    <li>
                                                        1:1 (1080x1080)
                                                    </li>
                                                    <li>
                                                        1:1 (1080x1080)
                                                    </li>
                                                </ul>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                                <div className='page-links-tab'>
                                    <ul>
                                        <li>
                                            <Link to={`${base_url}upload-3d-modal`} className='page-btn'> I Have a 3D model</Link>
                                        </li>
                                        <li>
                                            <Link to={`${base_url}upload-modal`} className='page-btn active'> I Don’t have a 3D model</Link>
                                        </li>
                                    </ul>
                                </div>
                                <div className='upload-actions-row'>
                                    <div className='single-upload-outer'>
                                        <div className='single-upload-action'>
                                            <div className='headings'>
                                                <h4 className='main-title'>Upload Product Images</h4>
                                                <p>	Supported formats: .JPG, .PNG, .GIF, .WEBP, .SVG</p>
                                            </div>
                                            <div className='upload-box-row'>
                                                <div className='col-upload-box'>
                                                    <h6 className='box-title'>Front View</h6>
                                                    <input className='d-none' type="file" id='modal-Front-file' />
                                                    <label htmlFor='modal-Front-file' className='upload-box-div'>
                                                        <img src={UplaodIcon} alt="UplaodIcon" />
                                                        <span className='text'><b>Click to upload</b> or drag and drop</span>
                                                    </label>
                                                </div>
                                                <div className='col-upload-box'>
                                                    <h6 className='box-title'>Side view</h6>
                                                    <input className='d-none' type="file" id='modal-Side-file' />
                                                    <label htmlFor='modal-Side-file' className='upload-box-div'>
                                                        <img src={UplaodIcon} alt="UplaodIcon" />
                                                        <span className='text'><b>Click to upload</b> or drag and drop</span>
                                                    </label>
                                                </div>
                                                <div className='col-upload-box'>
                                                    <h6 className='box-title'>Top view</h6>
                                                    <input className='d-none' type="file" id='modal-Top-file' />
                                                    <label htmlFor='modal-Top-file' className='upload-box-div'>
                                                        <img src={UplaodIcon} alt="UplaodIcon" />
                                                        <span className='text'><b>Click to upload</b> or drag and drop</span>
                                                    </label>
                                                </div>
                                                <div className='col-upload-box'>
                                                    <h6 className='box-title'>Bottom View</h6>
                                                    <input className='d-none' type="file" id='modal-Bottom-file' />
                                                    <label htmlFor='modal-Bottom-file' className='upload-box-div'>
                                                        <img src={UplaodIcon} alt="UplaodIcon" />
                                                        <span className='text'><b>Click to upload</b> or drag and drop</span>
                                                    </label>
                                                </div>
                                                <div className='col-upload-box'>
                                                    <h6 className='box-title'>Rear View</h6>
                                                    <input className='d-none' type="file" id='modal-Rear-file' />
                                                    <label htmlFor='modal-Rear-file' className='upload-box-div'>
                                                        <img src={UplaodIcon} alt="UplaodIcon" />
                                                        <span className='text'><b>Click to upload</b> or drag and drop</span>
                                                    </label>
                                                </div>
                                            </div>

                                        </div>
                                        <div className='single-upload-action'>
                                            <div className='headings mb-2'>
                                                <h4 className='main-title'>Add product dimensions</h4>
                                            </div>
                                            <div className='dimension-row'>
                                                <div className='form-group'>
                                                    <input className='form-control' type="text" placeholder='Width' />
                                                    <span>inch</span>
                                                </div>
                                                <div className='form-group'>
                                                    <input className='form-control' type="text" placeholder='Height' />
                                                    <span>inch</span>
                                                </div>
                                                <div className='form-group'>
                                                    <input className='form-control' type="text" placeholder='Depth' />
                                                    <span>inch</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div className='single-upload-action'>
                                            <div className='headings'>
                                                <h4 className='main-title'>Upload product label</h4>
                                                <p>	Supported formats: .JPG, .PNG, .GIF, .WEBP, .SVG</p>
                                            </div>
                                            <input className='d-none' type="file" id='product-3d-label' />
                                            <label htmlFor='product-3d-label' className='upload-box-div'>
                                                <img src={UplaodIcon} alt="UplaodIcon" />
                                                <span className='text'><b>Click to upload</b> or drag and drop</span>
                                            </label>
                                        </div>
                                        <div className='single-upload-action'>
                                            <div className='headings'>
                                                <h4 className='main-title'>Comments</h4>
                                            </div>
                                            <input className='form-control' placeholder='Enter additional details' type="text" />

                                        </div>
                                        <span className='note-text w-100'>
                                            <b>Note:</b> 150 credits are required for the creation of a 3D model by our team.
                                        </span>
                                    </div>
                                    <div className='single-upload-btns'>
                                        <button className='single-btn'>
                                            <img src={PlusIcon} alt="PlusIcon" />
                                            <span>Add more</span>
                                        </button>
                                        <button className='single-btn'>
                                            <img src={PlusIcon} alt="PlusIcon" />
                                            <span>Additional Labels</span>
                                        </button>
                                        <span className='note-text'>
                                            <b>Note:</b> Additional Labels requires a fee of 60 credits.
                                        </span>
                                    </div>
                                </div>

                                <div className='upload-payment-info'>
                                    <div className='credits-details'>
                                        <p>Total Credits</p>
                                        <h6 className='price'>250</h6>
                                    </div>
                                    <div className='upload-actions'>
                                        <button className='btn btn-secondary'>
                                            Cancel
                                        </button>
                                        <button className='btn btn-primary'>
                                            Upload
                                        </button>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                </section>
                {/* ===== FOOTER ===== */}
                <Footer />

            </main>

        </>
    )
}

export default Upload_Modals