import React from 'react'
import Footer from '../../common/footer/Footer'
import Header from '../../common/header/Header'
import UplaodIcon from "../../../assets/images/upload-icon.svg";
import PlusIcon from "../../../assets/images/plus-icon.svg";
import { Link } from 'react-router-dom'

const Upload_3d_Modals = () => {

    let base_url = process.env.REACT_APP_BASE_URL;



    return (

        <>
            <main className="upload-modals-page">
                {/* ===== HEADER ===== */}
                <Header />


                {/* ========== My Profile start ======= */}
                <section className='upload-modal-sec px-85'>
                    <div className="container-fluid">
                        <div className='upload-modal-row row'>
                            <div className="col-modal-form">
                                <div className='headings'>
                                    <h2>Upload products</h2>
                                    <p>Upload and attach files to this project.</p>
                                </div>
                                <div className='video-info'>
                                    <div className='head'>
                                        <div className='name-outer'>
                                            <div className='name'>
                                                <h6 className='info-title'>Video Name</h6>
                                                <p>6763</p>
                                            </div>
                                        </div>
                                        <div className='credits-dlt'>
                                            <div className='aspect-div'>
                                                <h6 className='info-title'>Aspect ratio selected</h6>
                                                <ul>
                                                    <li>
                                                        1:1 (1080x1080)
                                                    </li>
                                                    <li>
                                                        1:1 (1080x1080)
                                                    </li>
                                                </ul>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                                <div className='page-links-tab'>
                                    <ul>
                                        <li>
                                            <Link to={`${base_url}upload-3d-modal`} className='page-btn active'> I Have a 3D model</Link>
                                        </li>
                                        <li>
                                            <Link to={`${base_url}upload-modal`} className='page-btn'> I Don’t have a 3D model</Link>
                                        </li>
                                    </ul>
                                </div>
                                <div className='upload-actions-row'>
                                    <div className='single-upload-action'>
                                        <div className='headings'>
                                            <h4 className='main-title'>Upload 3D model file</h4>
                                            <p>	Supported formats: .OBJ, .FBX, .STL, .3DS, .DAE</p>
                                        </div>
                                        <input className='d-none' type="file" id='modal-3d-file'/>
                                        <label htmlFor='modal-3d-file' className='upload-box-div'>
                                            <img src={UplaodIcon} alt="UplaodIcon" />
                                            <p className='text'><b>Click to upload</b> <span>or drag and drop</span></p>
                                        </label>
                                    </div>
                                    <div className='single-upload-action'>
                                        <div className='headings'>
                                            <h4 className='main-title'>Upload product label</h4>
                                            <p>	Supported formats: .JPG, .PNG, .GIF, .WEBP, .SVG</p>
                                        </div>
                                        <input className='d-none' type="file" id='product-3d-label'/>
                                        <label htmlFor='product-3d-label' className='upload-box-div'>
                                            <img src={UplaodIcon} alt="UplaodIcon" />
                                            <p className='text'><b>Click to upload</b> <span>or drag and drop</span></p>
                                        </label>
                                    </div>
                                    <div className='single-upload-action'>
                                        <div className='headings'>
                                            <h4 className='main-title'>Comments</h4>
                                        </div>
                                        <input className='form-control' placeholder='Enter additional details' type="text"/>
                                        
                                    </div>
                                    <div className='single-upload-btns'>
                                        <button className='single-btn'>
                                            <img src={PlusIcon} alt="PlusIcon" />
                                            <span>Add more</span>
                                        </button>
                                        <button className='single-btn'>
                                            <img src={PlusIcon} alt="PlusIcon" />
                                            <span>Additional Labels</span>
                                        </button>
                                        <span className='note-text'>
                                            <b>Note:</b> Additional Labels requires a fee of 60 credits.
                                        </span>
                                    </div>
                                </div>

                                <div className='upload-payment-info'>
                                    <div className='credits-details'>
                                        <p>Total Credits</p>
                                        <h6 className='price'>250</h6>
                                    </div>
                                    <div className='upload-actions'>
                                        <button className='btn btn-secondary'>
                                            Cancel
                                        </button>
                                        <button className='btn btn-primary'>
                                            Upload
                                        </button>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                </section>
                {/* ===== FOOTER ===== */}
                <Footer />

            </main>

        </>

    )
}

export default Upload_3d_Modals