import React from "react";
import Header from "../../common/header/Header";
import Herosection from "../../common/herosection/Herosection";
import Tamplates_Sections from "../tamplates/tamplates_section/Tamplates_Sections";
import Ready_To_Start from "../ready_to_start/Ready_To_Start";
import Footer from "../../common/footer/Footer";
import Mobile_How_Works from "../mobile_how_works/Mobile_How_Works";

const Home_before_login = () => {
  return (
    <main className="home-without-login">
    {/* ===== HEADER ===== */}
    <Header />

    {/* ===== HERO SECTION ===== */}
    <Herosection />

    {/* ===== TEMPLATE SECTION ===== */}
    <Tamplates_Sections/>
       {/* ========== Mobile How Works ======= */}
      <Mobile_How_Works/>

   {/* ========== Ready To start ======= */}
   <Ready_To_Start/>


    {/* ===== FOOTER ===== */}
  <Footer/>
  </main>
  )
}

export default Home_before_login
