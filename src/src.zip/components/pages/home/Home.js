import React from 'react'
import Header from "../../common/header/Header";
import Header_Login from "../../common/header/Header_Login";
import Herosection from "../../common/herosection/Herosection";
import Footer from '../../common/footer/Footer';
import Template_Slider from '../tamplates/tamplates_section/Template_Slider';

const Home = () => {
  return (
     <main className="home-login">
    {/* ===== HEADER ===== */}
    {/* <Header/> */}
    <Header_Login/>

    {/* ===== HERO SECTION ===== */}
    <Herosection />

    {/* ===== TEMPLATE SECTION ===== */}
    <Template_Slider/>

   {/* ========== Ready To start ======= */}
  


    {/* ===== FOOTER ===== */}
  <Footer/>

  </main>
  )
}

export default Home