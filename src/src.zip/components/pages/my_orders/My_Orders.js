import React from 'react'
import Header_Login from "../../common/header/Header_Login";
import Footer from '../../common/footer/Footer';
import StepIcon from "../../../assets/images/step-active.svg";
import ListImg from "../../../assets/images/order-list.svg";
import commentImg from "../../../assets/images/comment.svg";
import playImg from "../../../assets/images/play-list.svg";
import { Link } from 'react-router-dom';
import Header from '../../common/header/Header';



const My_Orders = () => {



    return (
        <>

            <main className="orders-page">
                {/* ===== HEADER ===== */}
                {/* <Header_Login /> */}
                <Header/>

                <section className='orders-section px-85'>
                    <div className="container-fluid">
                        <div className='order-page-heading'>
                            <h1>My orders</h1>
                        </div>

                        <div className='order-table-outer'>
                            <div className='order-single-details'>
                                <div className='order-table-head'>
                                    <div className='single-order-step'>
                                        <img src={StepIcon} alt="StepIcon" />
                                        <div className='text'>
                                            <h6>Order placed</h6>
                                            <p>May 20th, 2024 - 10:30PM</p>
                                        </div>
                                        <span className='line'></span>
                                    </div>
                                    <div className='single-order-step active'>
                                        <div className='nbr'>
                                            2
                                        </div>
                                        <div className='text'>
                                            <h6>Model initiated</h6>
                                            <p>Demo video in progress</p>
                                        </div>
                                        <span className='line'></span>
                                    </div>
                                    <div className='single-order-step'>
                                        <div className='nbr'>
                                            3
                                        </div>
                                        <div className='text'>
                                            <h6>Model under review</h6>
                                            <p>Demo video under customer review</p>
                                        </div>
                                        <span className='line'></span>
                                    </div>
                                    <div className='single-order-step'>
                                        <div className='nbr'>
                                            4
                                        </div>
                                        <div className='text'>
                                            <h6>Model to be approved</h6>
                                            <p>Awaiting customer approval</p>
                                        </div>
                                        <span className='line'></span>
                                    </div>
                                    <div className='single-order-step'>
                                        <div className='nbr'>
                                            5
                                        </div>
                                        <div className='text'>
                                            <h6>Final model delivered</h6>
                                            <p>Final video is ready to download</p>
                                        </div>
                                    </div>
                                </div>
                                <div className='order-details-info'>
                                    <div className='left-info'>
                                        <div className='single-info status'>
                                            <p>Status</p>
                                            <span className='badge-tag'>Model initiated</span>
                                        </div>
                                        <div className='single-info'>
                                            <p>Order ID</p>
                                            <span>545678</span>
                                        </div>
                                        <div className='single-info'>
                                            <p>Video Name</p>
                                            <span>5678</span>
                                        </div>
                                        <div className='single-info date'>
                                            <p>Date</p>
                                            <span>May 20th, 2024 - 10:30PM</span>
                                        </div>
                                    </div>
                                    <div className='right-action'>
                                        <Link className='order-btn'>
                                            <img src={ListImg} alt="ListImg" />
                                            <span>Order details</span>
                                        </Link>
                                        <Link className='order-btn'>
                                            <img src={commentImg} alt="ListImg" />
                                            <span>Comments</span>
                                        </Link>
                                        <Link className='order-btn disabled'>
                                            <img src={playImg} alt="ListImg" />
                                            <span>Download Video</span>
                                        </Link>
                                    </div>
                                </div>
                            </div>
                            <div className='order-single-details'>
                                
                                <div className='order-details-info'>
                                    <div className='left-info'>
                                        <div className='single-info status'>
                                            <p>Status</p>
                                            <span className='badge-tag bg-success'>Approved</span>
                                        </div>
                                        <div className='single-info'>
                                            <p>Order ID</p>
                                            <span>545678</span>
                                        </div>
                                        <div className='single-info'>
                                            <p>Video Name</p>
                                            <span>5678</span>
                                        </div>
                                        <div className='single-info date'>
                                            <p>Date</p>
                                            <span>May 20th, 2024 - 10:30PM</span>
                                        </div>
                                    </div>
                                    <div className='right-action'>
                                        <Link className='order-btn'>
                                            <img src={ListImg} alt="ListImg" />
                                            <span>Order details</span>
                                        </Link>
                                        <Link className='order-btn'>
                                            <img src={commentImg} alt="ListImg" />
                                            <span>Comments</span>
                                        </Link>
                                        <Link className='order-btn'>
                                            <img src={playImg} alt="ListImg" />
                                            <span>Download Video</span>
                                        </Link>
                                    </div>
                                </div>
                            </div>
                            <div className='order-single-details'>
                                
                                <div className='order-details-info'>
                                    <div className='left-info'>
                                        <div className='single-info status'>
                                            <p>Status</p>
                                            <span className='badge-tag bg-success'>Approved</span>
                                        </div>
                                        <div className='single-info'>
                                            <p>Order ID</p>
                                            <span>545678</span>
                                        </div>
                                        <div className='single-info'>
                                            <p>Video Name</p>
                                            <span>5678</span>
                                        </div>
                                        <div className='single-info date'>
                                            <p>Date</p>
                                            <span>May 20th, 2024 - 10:30PM</span>
                                        </div>
                                    </div>
                                    <div className='right-action'>
                                        <Link className='order-btn'>
                                            <img src={ListImg} alt="ListImg" />
                                            <span>Order details</span>
                                        </Link>
                                        <Link className='order-btn'>
                                            <img src={commentImg} alt="ListImg" />
                                            <span>Comments</span>
                                        </Link>
                                        <Link className='order-btn'>
                                            <img src={playImg} alt="ListImg" />
                                            <span>Download Video</span>
                                        </Link>
                                    </div>
                                </div>
                            </div>
                            <div className='order-single-details'>
                                
                                <div className='order-details-info'>
                                    <div className='left-info'>
                                        <div className='single-info status'>
                                            <p>Status</p>
                                            <span className='badge-tag bg-success'>Approved</span>
                                        </div>
                                        <div className='single-info'>
                                            <p>Order ID</p>
                                            <span>545678</span>
                                        </div>
                                        <div className='single-info'>
                                            <p>Video Name</p>
                                            <span>5678</span>
                                        </div>
                                        <div className='single-info date'>
                                            <p>Date</p>
                                            <span>May 20th, 2024 - 10:30PM</span>
                                        </div>
                                    </div>
                                    <div className='right-action'>
                                        <Link className='order-btn'>
                                            <img src={ListImg} alt="ListImg" />
                                            <span>Order details</span>
                                        </Link>
                                        <Link className='order-btn'>
                                            <img src={commentImg} alt="ListImg" />
                                            <span>Comments</span>
                                        </Link>
                                        <Link className='order-btn'>
                                            <img src={playImg} alt="ListImg" />
                                            <span>Download Video</span>
                                        </Link>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>



                {/* ===== FOOTER ===== */}
                <Footer />

            </main>

        </>
    )
}

export default My_Orders