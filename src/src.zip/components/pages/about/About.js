import React, { useState } from 'react'
import Header from '../../common/header/Header'
import VisionImg from "../../../assets/images/vision.jpg";
import MissionImg from "../../../assets/images/mission.jpg";
import ReachStartImg from "../../../assets/images/about-start-img.png";
import { Link } from 'react-router-dom';
import Book_Call from '../../common/book_call_popup/Book_Call';
import Reach_Us_Form from '../../common/reach_out_form/Reach_Us_Form';


const About = () => {

  const [Bookshow, setBookShow] = useState(false);

  const handleBookShow = () => setBookShow(true);
  const handleBookClose = () => setBookShow(false);


  return (
    <>
      <main className="about-page">

        {/* ===== HEADER ===== */}
        <Header />

        <section className='about-banner px-85'>
          <div className="container-fluid">
            <div className='row banner-row'>
              <div className="col-about-banner">
                <div className='page-heading'>
                  <h1>
                    About Us
                  </h1>
                  <h2>We are Poly Craft - a powerful blend of creativity, technology and AI.</h2>
                  <p>
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                  </p>
                  <p>
                    Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                  </p>
                  <p>
                    It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className='about-content-sec px-85'>
          <div className="container-fluid">
            <div className='about-content-row'>
              <div className='col-text-box'>
                <div className='text-box'>
                  <h2>Our Vision</h2>
                  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                  <p>
                    Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                  </p>
                  <p>
                    It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                  </p>
                </div>
              </div>
              <div className='col-img-box'>
                <div className='img-box'>
                  <img src={VisionImg} alt="VisionImg" />
                </div>
              </div>
            </div>
            <div className='about-content-row'>
              <div className='col-img-box'>
                <div className='img-box'>
                  <img src={MissionImg} alt="MissionImg" />
                </div>
              </div>
              <div className='col-text-box'>
                <div className='text-box'>
                  <h2>Our Mission</h2>
                  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                  <p>
                    Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                  </p>
                  <p>
                    It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="px-85">
          <div className="container-fluid">
            <div className='ready-start-bg'>
              <div className='reach-start-row'>
                <div className='reach-start-text'>
                  <h2 className='gradient-text'>Ready to Start Creating?</h2>
                  <p>Sign up for a free account or explore our membership plans to unlock the full Poly Craft experience.</p>
                  <Link to='#' className='btn btn-primary'>
                    Let's Start
                  </Link>
                </div>
                <div className='reach-start-img'>
                  <img src={ReachStartImg} alt="ReachStartImg" />
                </div>
              </div>

            </div>
          </div>
        </section>

        <section className='book-call-btn'>
          <div className="container-fluid">
            <div className='col-book-btn about-us'>
              <button className='btn btn-primary' onClick={handleBookShow}>
                Book A Call
              </button>
              <Book_Call Bookshow={Bookshow} handleBookClose={handleBookClose} />
            </div>
          </div>
        </section>

        <Reach_Us_Form/>

      </main>

    </>
  )
}

export default About