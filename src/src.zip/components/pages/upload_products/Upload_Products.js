import React, { useState } from 'react'
import Header from '../../common/header/Header'
import Footer from '../../common/footer/Footer'
import HeroVideo from "../../../assets/images/placeholder-video.mp4";
import tamplates from "../../../assets/images/tamplates.png";
import DltIcon from "../../../assets/images/dlt-modal-icon.svg";
import TrashIcon from "../../../assets/images/trash.svg";
import UploadIcon from "../../../assets/images/uplaod-icon.svg";
import { Link } from 'react-router-dom';
import { CloseButton, Modal } from 'react-bootstrap';



const Upload_Products = () => {

    let base_url = process.env.REACT_APP_BASE_URL;

    const [Dltshow, setDltShow] = useState(false);

    const handleDltClose = () => setDltShow(false);
    const handleDltShow = () => setDltShow(true);


    const handleDeleteVideo = () => {
        alert('Deleting Video ....');
        setDltShow(false);
    };


    return (
        <>
            <main className="upload-products-page">
                {/* ===== HEADER ===== */}
                <Header />


                {/* ========== My Profile start ======= */}

                <section className='upload-products-section px-85'>
                    <div className="container-fluid">
                        <div className="row upload-row">
                            <div className='col-uplaod-form'>
                                <div className='upload-form'>
                                    <div className='heading'>
                                        Checkout
                                    </div>
                                    <div className='step-actions'>
                                        <div className='inner-step active'>
                                            <span className='nbr'>
                                                1
                                            </span>
                                            <div className=''>
                                                <h6>
                                                    Upload products
                                                </h6>
                                                <p>
                                                    Images & 3D models
                                                </p>
                                            </div>
                                            <span className='border-line'></span>
                                        </div>
                                        <div className='inner-step'>
                                            <span className='nbr'>
                                                2
                                            </span>
                                            <div className=''>
                                                <h6>
                                                    Payment details
                                                </h6>
                                                <p>
                                                    Review payment & checkout
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div className='cart-div'>
                                        <h3>Upload products (2)</h3>
                                        <div className='single-cart-product'>
                                            <div className='left-image'>
                                                <img src={tamplates} alt="" />
                                            </div>
                                            <div className='right-info'>
                                                <div className='head'>
                                                    <div className='name-outer'>
                                                        <div className='name'>
                                                            <h6 className='info-title'>Video Name</h6>
                                                            <p>6763</p>
                                                        </div>
                                                        <div className='credits-info'>
                                                            <h6 className='info-title'>Credits</h6>
                                                            <p>250 <span>100</span></p>
                                                        </div>
                                                    </div>
                                                    <div className='credits-dlt'>

                                                        <div className='aspect-div'>
                                                            <h6 className='info-title'>Aspect ratio selected</h6>
                                                            <ul>
                                                                <li>
                                                                    1:1 (1080x1080)
                                                                </li>
                                                                <li>
                                                                    1:1 (1080x1080)
                                                                </li>
                                                            </ul>
                                                        </div>
                                                        <button className='dlt-btn' onClick={handleDltShow}>
                                                            <img src={TrashIcon} alt="" />
                                                        </button>
                                                    </div>
                                                </div>
                                                <div className='upload-action'>
                                                    <h6 className='info-title mb-0'>Upload product</h6>
                                                    <p>
                                                        Please upload your product to complete the checkout.
                                                    </p>
                                                    <div className='upload-btn-outer'>
                                                        <Link to={`${base_url}upload-3d-modal`} className='btn btn-primary'>
                                                            <span className='me-2'> Upload </span>
                                                            <img src={UploadIcon} alt="" />
                                                        </Link>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className='single-cart-product'>
                                            <div className='left-image'>
                                                <img src={tamplates} alt="" />
                                            </div>
                                            <div className='right-info'>
                                                <div className='head'>
                                                    <div className='name-outer'>
                                                        <div className='name'>
                                                            <h6 className='info-title'>Video Name</h6>
                                                            <p>6763</p>
                                                        </div>
                                                        <div className='credits-info'>
                                                            <h6 className='info-title'>Credits</h6>
                                                            <p>250 <span>100</span></p>
                                                        </div>
                                                    </div>
                                                    <div className='credits-dlt'>

                                                        <div className='aspect-div'>
                                                            <h6 className='info-title'>Aspect ratio selected</h6>
                                                            <ul>
                                                                <li>
                                                                    1:1 (1080x1080)
                                                                </li>
                                                                <li>
                                                                    1:1 (1080x1080)
                                                                </li>
                                                            </ul>
                                                        </div>
                                                        <button className='dlt-btn' onClick={handleDltShow}>
                                                            <img src={TrashIcon} alt="" />
                                                        </button>
                                                    </div>
                                                </div>
                                                <div className='upload-action'>
                                                    <h6 className='info-title mb-0'>Upload product</h6>
                                                    <p>
                                                        Please upload your product to complete the checkout.
                                                    </p>
                                                    <div className='upload-btn-outer'>
                                                        <Link to={`${base_url}upload-3d-modal`} className='btn btn-primary'>
                                                            <span className='me-2'> Upload </span>
                                                            <img src={UploadIcon} alt="" />
                                                        </Link>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className='col-uplaod-video'>
                                <video controls muted>
                                    <source src={HeroVideo} />
                                </video>
                            </div>
                        </div>
                    </div>
                </section>


                <section className='back-upload-btn px-85'>
                    <div className="container-fluid">
                        <div className='col-back-btn'>
                            <Link to={`${base_url}choose-video`} className='btn btn-primary'>
                                Back
                            </Link>
                        </div>
                    </div>
                </section>
                {/* ========== My Profile End ======= */}


                {/* ===== FOOTER ===== */}
                <Footer />

                <Modal className='cancel-modal' show={Dltshow} onHide={handleDltClose} centered>

                    <Modal.Body>
                        <div className='cancel-modal-outer delete-modal'>
                            <div className='modal-head'>
                                <CloseButton onClick={handleDltClose} />
                                <img src={DltIcon} alt="Delete Icon" />
                                <div>

                                    <h2>Delete video?</h2>
                                    <p>Deleting <b>Video Name 5653</b> is permanent. Are you sure you want to proceed?</p>

                                </div>
                            </div>
                        </div>
                    </Modal.Body>
                    <Modal.Footer>
                        <button className='btn btn-secondary' onClick={handleDltClose}>
                            Cancel
                        </button>
                        <button className="btn btn-primary" onClick={handleDeleteVideo}>
                            Delete
                        </button>
                    </Modal.Footer>
                </Modal>
            </main>


        </>
    )
}

export default Upload_Products