import React from 'react'

const Admin_Dashboard = () => {
  return (
    <div>
      <h1>Hello this is admin dashboard</h1>
    </div>
  )
}

export default Admin_Dashboard
