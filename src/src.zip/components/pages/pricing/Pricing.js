import React, { useState } from 'react'
import Footer from '../../common/footer/Footer'
import Header from '../../common/header/Header'
import ProdOne from "../../../assets/images/prod1.png";
import ProdTwo from "../../../assets/images/prod2.png";
import priceListIcon from "../../../assets/images/price-list-icon.svg";
import CheckIcon from "../../../assets/images/checkicon.svg";
import XIcon from "../../../assets/images/Xicon.svg";
import Book_Call from '../../common/book_call_popup/Book_Call';
import MissionImg from "../../../assets/images/mission.jpg";



const Pricing = () => {

    const [isYearly, setIsYearly] = useState(false);
    // false = Monthly, true = Yearly

    const handleToggle = () => {
        setIsYearly(!isYearly);
    };

    const [Bookshow, setBookShow] = useState(false);

    const handleBookShow = () => setBookShow(true);
    const handleBookClose = () => setBookShow(false);

    const [isFeaturesOpen, setIsFeaturesOpen] = useState(false);
    const [isFeaturesOpen1, setIsFeaturesOpen1] = useState(false);
    const [isFeaturesOpen2, setIsFeaturesOpen2] = useState(false);
    const [isFeaturesOpen3, setIsFeaturesOpen3] = useState(false);

    const toggleFeatures = () => {
        setIsFeaturesOpen(!isFeaturesOpen);
    };
    const toggleFeatures1 = () => {
        setIsFeaturesOpen1(!isFeaturesOpen1);
    };
    const toggleFeatures2 = () => {
        setIsFeaturesOpen2(!isFeaturesOpen2);
    };
    const toggleFeatures3 = () => {
        setIsFeaturesOpen3(!isFeaturesOpen3);
    };
    return (
        <>

            <main className="upload-modals-page">
                {/* ===== HEADER ===== */}
                <Header />

                <section className='pricing-banner-sec px-85'>
                    <div className="container-fluid">
                        <div className='page-banner'>
                            <div className='page-banner-text'>
                                <h1>Discover the perfect plan for your brand</h1>
                                <p>Choose a pricing plan to get started</p>
                            </div>
                        </div>
                        <div className='pricing-model-row'>
                            <div className='col-pricing-text'>
                                <div className='left-text'>
                                    <span className='step-nbr'>STEP 1</span>
                                    <h2>Select a pricing for the model</h2>
                                    <div className='inner-product-row'>
                                        <div className='single-product-box'>
                                            <div className='text-box'>
                                                <h3>3D Model per product</h3>
                                                <p>150 <span>credits</span></p>
                                            </div>
                                            <div className='img-box'>
                                                <img src={ProdOne} alt="ProdOne" />
                                            </div>
                                        </div>
                                        <div className='single-product-box'>
                                            <div className='text-box'>
                                                <h3>For additional label</h3>
                                                <p>60 <span>credits</span></p>
                                            </div>
                                            <div className='img-box'>
                                                <img src={ProdTwo} alt="ProdTwo" />
                                            </div>
                                        </div>
                                    </div>
                                    <ul className='price-model-list'>
                                        <li>
                                            Create a professional 3D model of your product for a fraction of the cost
                                        </li>
                                        <li>
                                            Add an extra label for the same product with just a few additional credits
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div className='col-pricing-img'>
                                <img src={MissionImg} alt="MissionImg" />
                            </div>
                        </div>
                        <div className='pricing-model-row pb-0 mb-0 border-0'>
                            <div className='col-pricing-text'>
                                <div className='left-text'>
                                    <span className='step-nbr'>STEP 2</span>
                                    <h2>Choose one of our flexible options</h2>

                                </div>
                            </div>
                        </div>
                        <div className='pricing-table-row'>
                            <div className='pricing-table-outer'>
                                <div className='pricing-table-heading'>
                                    <h3>Poly Service</h3>
                                    <p>Our team will build high-quality, custom videos at scale, saving you time and money</p>
                                </div>
                                <div class="form-check form-switch">
                                    <label className={`form-check-label ${!isYearly ? 'active' : ''}`}>Monthly</label>
                                    <input
                                        className="form-check-input"
                                        type="checkbox"
                                        role="switch"
                                        id="switchCheckPrice"
                                        checked={isYearly}
                                        onChange={handleToggle}
                                    />
                                    <label className={`form-check-label ${isYearly ? 'active' : ''}`}>Yearly</label>
                                </div>
                            </div>

                            <div className='table-inner-row row'>
                                <div className='col-lg-3'>
                                    <div className='pricing-box'>
                                        <h2>Pay per video</h2>
                                        <p>Choose your own high-quality video without the high price tag</p>
                                        <div className='pricing-label-outer'>
                                            <div className='pricing-info'>
                                                <h3>PER VIDEO</h3>
                                                <h4>$250+ <span>USD</span></h4>
                                            </div>
                                        </div>
                                        <div className='features-div-outer'>
                                            <div className='features-content-outer'>
                                                <button className='features-toggle-button' onClick={toggleFeatures1}>
                                                    <span>Features </span>
                                                    <img src={priceListIcon} alt="priceListIcon" />
                                                </button>
                                                <div className={`features-content mt-3 ${isFeaturesOpen1 ? 'open' : ''}`}>
                                                    <ul className='dots-list'>
                                                        <li>
                                                            Zero-commitment flexibility
                                                        </li>
                                                        <li>
                                                            Get access to an extensive 3D template library
                                                        </li>
                                                    </ul>
                                                    <ul className='check-list'>
                                                        <li>
                                                            <img src={CheckIcon} alt="CheckIcon" />
                                                            <span>Pay as you go</span>
                                                        </li>

                                                        <li>
                                                            <img src={CheckIcon} alt="CheckIcon" />
                                                            <span>Requires product setup</span>
                                                        </li>
                                                        <li>
                                                            <img src={CheckIcon} alt="CheckIcon" />
                                                            <span>Access to short video clips</span>
                                                        </li>
                                                        <li>
                                                            <img src={CheckIcon} alt="CheckIcon" />
                                                            <span>Access to long videos (premium)</span>
                                                        </li>
                                                    </ul>
                                                    <h6 className='creative-heading'>CREATIVE</h6>
                                                    <ul className='creative-list'>
                                                        <li>
                                                            <img src={CheckIcon} alt="CheckIcon" />
                                                            <span>Change text</span>
                                                        </li>
                                                        <li>
                                                            <img src={CheckIcon} alt="CheckIcon" />
                                                            <span>Change background image</span>
                                                        </li>
                                                        <li>
                                                            <img src={XIcon} alt="XIcon" />
                                                            <span className='xtext'>Unlimited Revisions</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <button className='btn btn-primary w-100'>GET STARTED</button>
                                    </div>
                                </div>
                                <div className='col-lg-3'>
                                    <div className='pricing-box'>

                                        <div className='pricing-label-outer'>
                                            <div className='pricing-info'>
                                                <h3>SILVER</h3>
                                                <h4>$600 <span>USD</span> </h4>
                                                <span className='period'>month</span>
                                            </div>
                                            <div className='bonus-box-outer'>
                                                <h5>+50</h5>
                                                <p>Monthly Bonus credits</p>
                                            </div>
                                        </div>
                                        <div className='features-div-outer'>
                                            <div className='features-content-outer'>
                                                <button className='features-toggle-button' onClick={toggleFeatures}>
                                                    <span>Features </span>
                                                    <img src={priceListIcon} alt="priceListIcon" />
                                                </button>
                                                <div className={`features-content mt-3 ${isFeaturesOpen ? 'open' : ''}`}>
                                                    <h6 className='list-heading'>Membership Includes:</h6>
                                                    <ul className='check-list'>
                                                        <li>
                                                            <img src={CheckIcon} alt="CheckIcon" />
                                                            <span>$650 worth of Credits to spend on Content</span>
                                                        </li>

                                                        <li>
                                                            <img src={CheckIcon} alt="CheckIcon" />
                                                            <span>Unlimited Revisions</span>
                                                        </li>
                                                        <li>
                                                            <img src={CheckIcon} alt="CheckIcon" />
                                                            <span>Seamlessly integrate your brand assets</span>
                                                        </li>
                                                        <li>
                                                            <img src={CheckIcon} alt="CheckIcon" />
                                                            <span>Enjoy the best of handcrafted and AI-generated product videos</span>
                                                        </li>
                                                        <li>
                                                            <img src={CheckIcon} alt="CheckIcon" />
                                                            <span>Delightful feature five</span>
                                                        </li>
                                                    </ul>
                                                    <h6 className='creative-heading'>CREATIVE</h6>
                                                    <ul className='creative-list'>
                                                        <li>
                                                            <img src={CheckIcon} alt="CheckIcon" />
                                                            <span>Change text</span>
                                                        </li>
                                                        <li>
                                                            <img src={CheckIcon} alt="CheckIcon" />
                                                            <span>Change background image</span>
                                                        </li>
                                                        <li>
                                                            <img src={CheckIcon} alt="CheckIcon" />
                                                            <span>Change background color</span>
                                                        </li>
                                                        <li>
                                                            <img src={CheckIcon} alt="CheckIcon" />
                                                            <span>Access to all short videos</span>
                                                        </li>
                                                        <li>
                                                            <img src={CheckIcon} alt="CheckIcon" />
                                                            <span>Access to premium videos (longer)</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <button className='btn btn-primary w-100'>GET STARTED</button>
                                    </div>
                                </div>
                                <div className='col-lg-3'>
                                    <div className='pricing-box'>

                                        <div className='pricing-label-outer'>
                                            <div className='pricing-info'>
                                                <h3>Gold</h3>
                                                <h4>$1,600 <span>USD</span> </h4>
                                                <span className='period'>month</span>
                                            </div>
                                            <div className='bonus-box-outer'>
                                                <h5>+200</h5>
                                                <p>Monthly Bonus credits</p>
                                            </div>
                                        </div>
                                        <div className='features-div-outer'>
                                            <div className='features-content-outer'>
                                                <button className='features-toggle-button' onClick={toggleFeatures2}>
                                                    <span>Features </span>
                                                    <img src={priceListIcon} alt="priceListIcon" />
                                                </button>
                                                <div className={`features-content mt-3 ${isFeaturesOpen2 ? 'open' : ''}`}>
                                                    <h6 className='list-heading'>Membership Includes:</h6>
                                                    <ul className='check-list'>
                                                        <li>
                                                            <img src={CheckIcon} alt="CheckIcon" />
                                                            <span>$1800 worth of Credits to spend on Content</span>
                                                        </li>

                                                        <li>
                                                            <img src={CheckIcon} alt="CheckIcon" />
                                                            <span>Unlimited Revisions</span>
                                                        </li>
                                                        <li>
                                                            <img src={CheckIcon} alt="CheckIcon" />
                                                            <span>Seamlessly integrate your brand assets</span>
                                                        </li>
                                                        <li>
                                                            <img src={CheckIcon} alt="CheckIcon" />
                                                            <span>Enjoy the best of handcrafted and AI-generated product videos</span>
                                                        </li>
                                                        <li>
                                                            <img src={CheckIcon} alt="CheckIcon" />
                                                            <span>Delightful feature five</span>
                                                        </li>
                                                    </ul>
                                                    <h6 className='creative-heading'>CREATIVE</h6>
                                                    <ul className='creative-list'>
                                                        <li>
                                                            <img src={CheckIcon} alt="CheckIcon" />
                                                            <span>Change text</span>
                                                        </li>
                                                        <li>
                                                            <img src={CheckIcon} alt="CheckIcon" />
                                                            <span>Change background image</span>
                                                        </li>
                                                        <li>
                                                            <img src={CheckIcon} alt="CheckIcon" />
                                                            <span>Change background color</span>
                                                        </li>
                                                        <li>
                                                            <img src={CheckIcon} alt="CheckIcon" />
                                                            <span>Access to all short videos</span>
                                                        </li>
                                                        <li>
                                                            <img src={CheckIcon} alt="CheckIcon" />
                                                            <span>Access to premium videos (longer)</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <button className='btn btn-primary w-100'>GET STARTED</button>

                                        </div>

                                    </div>
                                </div>
                                <div className='col-lg-3'>
                                    <div className='pricing-box'>

                                        <div className='pricing-label-outer'>
                                            <div className='pricing-info'>
                                                <h3>Platinum</h3>
                                                <h4>$3,700 <span>USD</span> </h4>
                                                <span className='period'>month</span>
                                            </div>
                                            <div className='bonus-box-outer'>
                                                <h5>+500</h5>
                                                <p>Monthly Bonus credits</p>
                                            </div>
                                        </div>
                                        <div className='features-div-outer'>
                                            <div className='features-content-outer'>
                                                <button className='features-toggle-button' onClick={toggleFeatures3}>
                                                    <span>Features </span>
                                                    <img src={priceListIcon} alt="priceListIcon" />
                                                </button>
                                                <div className={`features-content mt-3 ${isFeaturesOpen3 ? 'open' : ''}`}>
                                                    <h6 className='list-heading'>Membership Includes:</h6>
                                                    <ul className='check-list'>
                                                        <li>
                                                            <img src={CheckIcon} alt="CheckIcon" />
                                                            <span>$4200 worth of Credits to spend on Content</span>
                                                        </li>

                                                        <li>
                                                            <img src={CheckIcon} alt="CheckIcon" />
                                                            <span>Unlimited Revisions</span>
                                                        </li>
                                                        <li>
                                                            <img src={CheckIcon} alt="CheckIcon" />
                                                            <span>Seamlessly integrate your brand assets</span>
                                                        </li>
                                                        <li>
                                                            <img src={CheckIcon} alt="CheckIcon" />
                                                            <span>Enjoy the best of handcrafted and AI-generated product videos</span>
                                                        </li>
                                                        <li>
                                                            <img src={CheckIcon} alt="CheckIcon" />
                                                            <span>Delightful feature five</span>
                                                        </li>
                                                    </ul>
                                                    <h6 className='creative-heading'>CREATIVE</h6>
                                                    <ul className='creative-list'>
                                                        <li>
                                                            <img src={CheckIcon} alt="CheckIcon" />
                                                            <span>Change text</span>
                                                        </li>
                                                        <li>
                                                            <img src={CheckIcon} alt="CheckIcon" />
                                                            <span>Change background image</span>
                                                        </li>
                                                        <li>
                                                            <img src={CheckIcon} alt="CheckIcon" />
                                                            <span>Change background color</span>
                                                        </li>
                                                        <li>
                                                            <img src={CheckIcon} alt="CheckIcon" />
                                                            <span>Access to all short videos</span>
                                                        </li>
                                                        <li>
                                                            <img src={CheckIcon} alt="CheckIcon" />
                                                            <span>Access to premium videos (longer)</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>

                                        <button className='btn btn-primary w-100'>GET STARTED</button>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </section>

                <section className='book-call-btn'>
                    <div className="container-fluid">
                        <div className='col-book-btn about-us'>
                            <button className='btn btn-primary' onClick={handleBookShow}>
                                Book A Call
                            </button>
                            <Book_Call Bookshow={Bookshow} handleBookClose={handleBookClose} />
                        </div>
                    </div>
                </section>

                <section className='pricing-works px-85'>
                    <div className="container-fluid">
                        <div className='col-pricing-works'>
                            <div className='pricing-works-box'>
                                <h2>How it works</h2>
                                <h6>Intelligent automation with a human touch</h6>
                                <p>
                                    Our 3D models, pre-designed video templates, and high-performance rendering engine make it easy to produce captivating videos that showcase your products in full detail.
                                </p>
                            </div>
                        </div>
                    </div>
                </section>


                {/* ===== FOOTER ===== */}
                <Footer />

            </main>
        </>
    )
}

export default Pricing