import React, { useRef, useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation, Pagination } from "swiper/modules";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import tamplates from "../../../assets/images/tamplates.png";
import ChooseImg from "../../../assets/images/choose-video.png";
import HeroVideo from "../../../assets/images/placeholder-video.mp4";
import PlayIcon from "../../../assets/images/play-icon.png";
import Header from '../../common/header/Header'
import Footer from '../../common/footer/Footer'

const Choose_Video = () => {

    const prevRef = useRef(null);
    const nextRef = useRef(null);
    const paginationRef = useRef(null);

    const templateImages = Array(8).fill(tamplates);


    return (
        <>
            {/* ===== HEADER ===== */}
            <Header />

            {/* ===== HERO SECTION ===== */}

            <section className='choose-video-sec px-85'>
                <div className="container-fluid">
                    <div className='choose-video-outer'>
                        <div className='heading'>Video 00001</div>
                        <div className='choose-video-left'>
                            <div className="left-video">
                                <div className="video-outer">
                                    <video controls muted>
                                        <source src={HeroVideo} />
                                    </video>
                                    {/* <img src={ChooseImg} alt="" /> */}
                                    {/* <button className="play-btn">
                                        <img src={PlayIcon} alt="" />
                                    </button> */}
                                </div>
                            </div>
                            <div className="video-info-outer">
                                <div className="credit-div">
                                    <div className="head">
                                        <div className="price">
                                            <span>
                                                Credits
                                            </span>
                                            <h6>
                                                250
                                            </h6>
                                        </div>
                                        <button className="btn btn-primary">
                                            Add to Cart
                                        </button>
                                    </div>
                                    <div className="aspect-ratio">
                                        <h6>Select aspect ratio</h6>
                                        <ul>
                                            <li>
                                                <input type="checkbox" className="btn-check" id="btn-check" autocomplete="off" />
                                                <label className="btn" htmlFor="btn-check">1:1 (1080x1080)</label>
                                            </li>
                                            <li>
                                                <input type="checkbox" className="btn-check" id="btn-check1" autocomplete="off" />
                                                <label className="btn" htmlFor="btn-check1">9:16 (1080x1920)</label>
                                            </li>
                                            <li>
                                                <input type="checkbox" className="btn-check" id="btn-check2" autocomplete="off" />
                                                <label className="btn" htmlFor="btn-check2">16:9 (1920x1080)</label>
                                            </li>
                                            <li>
                                                <input type="checkbox" className="btn-check" id="btn-check3" autocomplete="off" />
                                                <label className="btn" htmlFor="btn-check3">4:5 (1080x1350)</label>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="video-desc">
                                    <h6 className="fw-semibold">Video Description:</h6>
                                    <p className="fw-medium">
                                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.,
                                    </p>

                                    <div className="add-cart-box">
                                        <h4>Get all sizes and <b>Save more</b></h4>
                                        <div className="action-footer">
                                            <div className="price">
                                                <h6>
                                                    CREDITS
                                                </h6>
                                                <p>300 <span>400</span></p>
                                            </div>
                                            <button className="add-wh-btn">
                                                Add to Cart
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section className="idea-section px-85">
                <div className="container-fluid">
                    <div className="your-ideas-box">
                        <div className="col-video">
                            <video controls muted>
                                <source src={HeroVideo} />
                            </video>
                        </div>
                        <div className="col-text">
                            <h2>See how Polycrafts brings your ideas to life!</h2>
                            <p>
                                Watch this video to see how you can use Polycrafts to create stunning custom 3D ads that elevates your brand.
                            </p>
                            <h6>What can be customized</h6>
                            <ul>
                                <li>
                                    <button>
                                        Products
                                    </button>
                                </li>
                                <li>
                                    <button>
                                        Environments
                                    </button>
                                </li>
                                <li>
                                    <button>
                                        Colors
                                    </button>
                                </li>
                                <li>
                                    <button>
                                        Ingredients
                                    </button>
                                </li>
                                <li>
                                    <button>
                                        Multiple Products
                                    </button>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </section>

            <section className="image-slider pt-0">
                <div className="container-fluid">
                    <span className="like-text">You may also like</span>
                    <div className="row head-row">
                        <div className="col-lg-6 col-9">
                            <div className="headings">
                                <h2>HEADING 02</h2>
                                <p>
                                    Each template is valued at 400 credits.
                                </p>
                            </div>
                        </div>
                        <div className="col-lg-6 col-3">
                            {/* Custom Arrows */}
                            <div className="swiper-custom-nav">
                                <button ref={prevRef} className="custom-button">
                                    <svg width="16" height="27" viewBox="0 0 16 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M14 1.96141L2 13.4999L14 25.0383" stroke="#222222" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>

                                </button>
                                {/* Custom Dots */}
                                <div ref={paginationRef} className="custom-pagination"></div>
                                <button ref={nextRef} className="custom-button">
                                    <svg width="16" height="27" viewBox="0 0 16 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M2 25L14 13.5L2 2" stroke="#222222" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </button>
                            </div>


                        </div>
                    </div>

                    <div className="row image-row">
                        <div className="image-slider-outer login-home">
                            <Swiper
                                modules={[Navigation, Pagination]}
                                slidesPerView={5.65}
                                spaceBetween={24}
                                navigation={{
                                    prevEl: prevRef.current,
                                    nextEl: nextRef.current,
                                }}
                                pagination={{
                                    el: paginationRef.current,
                                    clickable: true,
                                }}
                                breakpoints={{
                                    0: {
                                        slidesPerView: 1.35,
                                    },
                                    768: {
                                        slidesPerView: 3.65,
                                    },
                                    1025: {
                                        slidesPerView: 4.65,
                                    },
                                    1450: {
                                        slidesPerView: 5.65,
                                    },
                                }}
                                onBeforeInit={(swiper) => {
                                    swiper.params.navigation.prevEl = prevRef.current;
                                    swiper.params.navigation.nextEl = nextRef.current;
                                    swiper.params.pagination.el = paginationRef.current;
                                }}
                            >
                                {templateImages.map((imgSrc, index) => (
                                    <SwiperSlide key={index}>
                                        <div className="img-box">
                                            <img
                                                src={imgSrc}
                                                alt={`template-${index}`}
                                                className="inner-pic"
                                            />
                                            <h6>Video name</h6>
                                        </div>
                                    </SwiperSlide>
                                ))}
                            </Swiper>

                        </div>
                    </div>
                </div>


            </section>

            {/* ===== FOOTER ===== */}
            <Footer />

        </>
    )
}

export default Choose_Video