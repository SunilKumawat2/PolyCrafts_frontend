// import React, { useRef, useState } from "react";
// import { Swiper, SwiperSlide } from "swiper/react";
// import { Navigation, Pagination } from "swiper/modules";
// import "swiper/css";
// import "swiper/css/navigation";
// import "swiper/css/pagination";
// import tamplates from "../../../../assets/images/tamplates.png";
// import NotepadIcon from "../../../../assets/images/notepad.svg";
// import { Link } from "react-router-dom";

// const Template_Slider = () => {


//     const prevRef = useRef(null);
//     const nextRef = useRef(null);
//     const paginationRef = useRef(null);

//     const templateImages = Array(8).fill(tamplates);



//     return (
//         <>

//             <section className="image-slider">
//                 <div className="container-fluid">

//                     <div className="row head-row">
//                         <div className="col-lg-6 col-9">
//                             <div className="headings">
//                                 <h2>HEADING 01</h2>
//                                 <p>
//                                     Each template is valued at 250 credits.
//                                 </p>
//                             </div>
//                         </div>
//                         <div className="col-lg-6 col-3">
//                             {/* Custom Arrows */}
//                             <div className="swiper-custom-nav">
//                                 <button ref={prevRef} className="custom-button">
//                                     <svg width="16" height="27" viewBox="0 0 16 27" fill="none" xmlns="http://www.w3.org/2000/svg">
//                                         <path d="M14 1.96141L2 13.4999L14 25.0383" stroke="#222222" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
//                                     </svg>

//                                 </button>
//                                 {/* Custom Dots */}
//                                 <div ref={paginationRef} className="custom-pagination"></div>
//                                 <button ref={nextRef} className="custom-button">
//                                     <svg width="16" height="27" viewBox="0 0 16 27" fill="none" xmlns="http://www.w3.org/2000/svg">
//                                         <path d="M2 25L14 13.5L2 2" stroke="#222222" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
//                                     </svg>
//                                 </button>
//                             </div>


//                         </div>
//                     </div>

//                     <div className="row image-row">
//                         <div className="image-slider-outer login-home">
//                             <Swiper
//                                 modules={[Navigation, Pagination]}
//                                 slidesPerView={5.65}
//                                 spaceBetween={24}
//                                 navigation={{
//                                     prevEl: prevRef.current,
//                                     nextEl: nextRef.current,
//                                 }}
//                                 pagination={{
//                                     el: paginationRef.current,
//                                     clickable: true,
//                                 }}
//                                 breakpoints={{
//                                     0: {
//                                         slidesPerView: 1.35,
//                                     },
//                                     768: {
//                                         slidesPerView: 3.65,
//                                     },
//                                     1025: {
//                                         slidesPerView: 4.65,
//                                     },
//                                     1450: {
//                                         slidesPerView: 5.65,
//                                     },
//                                 }}
//                                 onBeforeInit={(swiper) => {
//                                     swiper.params.navigation.prevEl = prevRef.current;
//                                     swiper.params.navigation.nextEl = nextRef.current;
//                                     swiper.params.pagination.el = paginationRef.current;
//                                 }}
//                             >
//                                 {templateImages.map((imgSrc, index) => (
//                                     <SwiperSlide key={index}>
//                                         <div className="img-box">
//                                             <img
//                                                 src={imgSrc}
//                                                 alt={`template-${index}`}
//                                                 className="inner-pic"
//                                             />
//                                             <h6>Video name</h6>
//                                         </div>
//                                     </SwiperSlide>
//                                 ))}
//                             </Swiper>

//                         </div>
//                     </div>
//                 </div>


//             </section>

//             {/* Second section start  */}

//             <section className="image-slider pt-0">
//                 <div className="container-fluid">

//                     <div className="row head-row">
//                         <div className="col-lg-6 col-9">
//                             <div className="headings">
//                                 <h2>HEADING 02</h2>
//                                 <p>
//                                     Each template is valued at 400 credits.
//                                 </p>
//                             </div>
//                         </div>
//                         <div className="col-lg-6 col-3">
//                             {/* Custom Arrows */}
//                             <div className="swiper-custom-nav">
//                                 <button ref={prevRef} className="custom-button">
//                                     <svg width="16" height="27" viewBox="0 0 16 27" fill="none" xmlns="http://www.w3.org/2000/svg">
//                                         <path d="M14 1.96141L2 13.4999L14 25.0383" stroke="#222222" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
//                                     </svg>

//                                 </button>
//                                 {/* Custom Dots */}
//                                 <div ref={paginationRef} className="custom-pagination"></div>
//                                 <button ref={nextRef} className="custom-button">
//                                     <svg width="16" height="27" viewBox="0 0 16 27" fill="none" xmlns="http://www.w3.org/2000/svg">
//                                         <path d="M2 25L14 13.5L2 2" stroke="#222222" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
//                                     </svg>
//                                 </button>
//                             </div>


//                         </div>
//                     </div>

//                     <div className="row image-row">
//                         <div className="image-slider-outer login-home">
//                             <Swiper
//                                 modules={[Navigation, Pagination]}
//                                 slidesPerView={5.65}
//                                 spaceBetween={24}
//                                 navigation={{
//                                     prevEl: prevRef.current,
//                                     nextEl: nextRef.current,
//                                 }}
//                                 pagination={{
//                                     el: paginationRef.current,
//                                     clickable: true,
//                                 }}
//                                 breakpoints={{
//                                     0: {
//                                         slidesPerView: 1.35,
//                                     },
//                                     768: {
//                                         slidesPerView: 3.65,
//                                     },
//                                     1025: {
//                                         slidesPerView: 4.65,
//                                     },
//                                     1450: {
//                                         slidesPerView: 5.65,
//                                     },
//                                 }}
//                                 onBeforeInit={(swiper) => {
//                                     swiper.params.navigation.prevEl = prevRef.current;
//                                     swiper.params.navigation.nextEl = nextRef.current;
//                                     swiper.params.pagination.el = paginationRef.current;
//                                 }}
//                             >
//                                 {templateImages.map((imgSrc, index) => (
//                                     <SwiperSlide key={index}>
//                                         <div className="img-box">
//                                             <img
//                                                 src={imgSrc}
//                                                 alt={`template-${index}`}
//                                                 className="inner-pic"
//                                             />
//                                             <h6>Video name</h6>
//                                         </div>
//                                     </SwiperSlide>
//                                 ))}
//                             </Swiper>

//                         </div>
//                     </div>
//                 </div>


//             </section>

//             {/* Third section start  */}

//             <section className="image-slider pt-0">
//                 <div className="container-fluid">

//                     <div className="row head-row">
//                         <div className="col-lg-6 col-9">
//                             <div className="headings">
//                                 <h2>HEADING 03</h2>
//                                 <p>
//                                     Each template is valued at 600 credits.
//                                 </p>
//                             </div>
//                         </div>
//                         <div className="col-lg-6 col-3">
//                             {/* Custom Arrows */}
//                             <div className="swiper-custom-nav">
//                                 <button ref={prevRef} className="custom-button">
//                                     <svg width="16" height="27" viewBox="0 0 16 27" fill="none" xmlns="http://www.w3.org/2000/svg">
//                                         <path d="M14 1.96141L2 13.4999L14 25.0383" stroke="#222222" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
//                                     </svg>

//                                 </button>
//                                 {/* Custom Dots */}
//                                 <div ref={paginationRef} className="custom-pagination"></div>
//                                 <button ref={nextRef} className="custom-button">
//                                     <svg width="16" height="27" viewBox="0 0 16 27" fill="none" xmlns="http://www.w3.org/2000/svg">
//                                         <path d="M2 25L14 13.5L2 2" stroke="#222222" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
//                                     </svg>
//                                 </button>
//                             </div>


//                         </div>
//                     </div>

//                     <div className="row image-row">
//                         <div className="image-slider-outer login-home">
//                             <Swiper
//                                 modules={[Navigation, Pagination]}
//                                 slidesPerView={5.65}
//                                 spaceBetween={24}
//                                 navigation={{
//                                     prevEl: prevRef.current,
//                                     nextEl: nextRef.current,
//                                 }}
//                                 pagination={{
//                                     el: paginationRef.current,
//                                     clickable: true,
//                                 }}
//                                 breakpoints={{
//                                     0: {
//                                         slidesPerView: 1.35,
//                                     },
//                                     768: {
//                                         slidesPerView: 3.65,
//                                     },
//                                     1025: {
//                                         slidesPerView: 4.65,
//                                     },
//                                     1450: {
//                                         slidesPerView: 5.65,
//                                     },
//                                 }}
//                                 onBeforeInit={(swiper) => {
//                                     swiper.params.navigation.prevEl = prevRef.current;
//                                     swiper.params.navigation.nextEl = nextRef.current;
//                                     swiper.params.pagination.el = paginationRef.current;
//                                 }}
//                             >
//                                 {templateImages.map((imgSrc, index) => (
//                                     <SwiperSlide key={index}>
//                                         <div className="img-box">
//                                             <img
//                                                 src={imgSrc}
//                                                 alt={`template-${index}`}
//                                                 className="inner-pic"
//                                             />
//                                             <h6>Video name</h6>
//                                         </div>
//                                     </SwiperSlide>
//                                 ))}
//                             </Swiper>

//                         </div>
//                     </div>
//                 </div>


//             </section>

//             {/* Fourth section start  */}

//             <section className="image-slider pt-0">
//                 <div className="container-fluid">

//                     <div className="row head-row">
//                         <div className="col-lg-6 col-9">
//                             <div className="headings">
//                                 <h2>HEADING 04</h2>
//                                 <p>
//                                     Each template is valued at 250 credits.
//                                 </p>
//                             </div>
//                         </div>
//                         <div className="col-lg-6 col-3">
//                             {/* Custom Arrows */}
//                             <div className="swiper-custom-nav">
//                                 <button ref={prevRef} className="custom-button">
//                                     <svg width="16" height="27" viewBox="0 0 16 27" fill="none" xmlns="http://www.w3.org/2000/svg">
//                                         <path d="M14 1.96141L2 13.4999L14 25.0383" stroke="#222222" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
//                                     </svg>

//                                 </button>
//                                 {/* Custom Dots */}
//                                 <div ref={paginationRef} className="custom-pagination"></div>
//                                 <button ref={nextRef} className="custom-button">
//                                     <svg width="16" height="27" viewBox="0 0 16 27" fill="none" xmlns="http://www.w3.org/2000/svg">
//                                         <path d="M2 25L14 13.5L2 2" stroke="#222222" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
//                                     </svg>
//                                 </button>
//                             </div>


//                         </div>
//                     </div>

//                     <div className="row image-row">
//                         <div className="image-slider-outer login-home">
//                             <Swiper
//                                 modules={[Navigation, Pagination]}
//                                 slidesPerView={5.65}
//                                 spaceBetween={24}
//                                 navigation={{
//                                     prevEl: prevRef.current,
//                                     nextEl: nextRef.current,
//                                 }}
//                                 pagination={{
//                                     el: paginationRef.current,
//                                     clickable: true,
//                                 }}
//                                 breakpoints={{
//                                     0: {
//                                         slidesPerView: 1.35,
//                                     },
//                                     768: {
//                                         slidesPerView: 3.65,
//                                     },
//                                     1025: {
//                                         slidesPerView: 4.65,
//                                     },
//                                     1450: {
//                                         slidesPerView: 5.65,
//                                     },
//                                 }}
//                                 onBeforeInit={(swiper) => {
//                                     swiper.params.navigation.prevEl = prevRef.current;
//                                     swiper.params.navigation.nextEl = nextRef.current;
//                                     swiper.params.pagination.el = paginationRef.current;
//                                 }}
//                             >
//                                 {templateImages.map((imgSrc, index) => (
//                                     <SwiperSlide key={index}>
//                                         <div className="img-box">
//                                             <img
//                                                 src={imgSrc}
//                                                 alt={`template-${index}`}
//                                                 className="inner-pic"
//                                             />
//                                             <h6>Video name</h6>
//                                         </div>
//                                     </SwiperSlide>
//                                 ))}
//                             </Swiper>

//                         </div>
//                     </div>
//                 </div>


//             </section>

//             {/* Fifth section start  */}

//             <section className="image-slider pt-0">
//                 <div className="container-fluid">

//                     <div className="row head-row">
//                         <div className="col-lg-6 col-9">
//                             <div className="headings">
//                                 <h2>HEADING 05</h2>
//                                 <p>
//                                     Each template is valued at 600 credits.
//                                 </p>
//                             </div>
//                         </div>
//                         <div className="col-lg-6 col-3">
//                             {/* Custom Arrows */}
//                             <div className="swiper-custom-nav">
//                                 <button ref={prevRef} className="custom-button">
//                                     <svg width="16" height="27" viewBox="0 0 16 27" fill="none" xmlns="http://www.w3.org/2000/svg">
//                                         <path d="M14 1.96141L2 13.4999L14 25.0383" stroke="#222222" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
//                                     </svg>

//                                 </button>
//                                 {/* Custom Dots */}
//                                 <div ref={paginationRef} className="custom-pagination"></div>
//                                 <button ref={nextRef} className="custom-button">
//                                     <svg width="16" height="27" viewBox="0 0 16 27" fill="none" xmlns="http://www.w3.org/2000/svg">
//                                         <path d="M2 25L14 13.5L2 2" stroke="#222222" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
//                                     </svg>
//                                 </button>
//                             </div>


//                         </div>
//                     </div>

//                     <div className="row image-row">
//                         <div className="image-slider-outer login-home">
//                             <Swiper
//                                 modules={[Navigation, Pagination]}
//                                 slidesPerView={5.65}
//                                 spaceBetween={24}
//                                 navigation={{
//                                     prevEl: prevRef.current,
//                                     nextEl: nextRef.current,
//                                 }}
//                                 pagination={{
//                                     el: paginationRef.current,
//                                     clickable: true,
//                                 }}
//                                 breakpoints={{
//                                     0: {
//                                         slidesPerView: 1.35,
//                                     },
//                                     768: {
//                                         slidesPerView: 3.65,
//                                     },
//                                     1025: {
//                                         slidesPerView: 4.65,
//                                     },
//                                     1450: {
//                                         slidesPerView: 5.65,
//                                     },
//                                 }}
//                                 onBeforeInit={(swiper) => {
//                                     swiper.params.navigation.prevEl = prevRef.current;
//                                     swiper.params.navigation.nextEl = nextRef.current;
//                                     swiper.params.pagination.el = paginationRef.current;
//                                 }}
//                             >
//                                 {templateImages.map((imgSrc, index) => (
//                                     <SwiperSlide key={index}>
//                                         <div className="img-box">
//                                             <img
//                                                 src={imgSrc}
//                                                 alt={`template-${index}`}
//                                                 className="inner-pic"
//                                             />
//                                             <h6>Video name</h6>
//                                         </div>
//                                     </SwiperSlide>
//                                 ))}
//                             </Swiper>

//                         </div>
//                     </div>
//                 </div>


//             </section>
//         </>
//     )
// }

// export default Template_Slider

import React, { useRef, useState, useEffect } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation, Pagination } from "swiper/modules";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import tamplates from "../../../../assets/images/tamplates.png";
import NotepadIcon from "../../../../assets/images/notepad.svg";
import { Link } from "react-router-dom";

const Template_Slider = () => {
  const prevRef = useRef(null);
  const nextRef = useRef(null);
  const paginationRef = useRef(null);

  const templateImages = Array(8).fill(tamplates);

  // Modal & hover state
  const [isOpen, setIsOpen] = useState(false);
  const [selectedImage, setSelectedImage] = useState(null);
  const [closing, setClosing] = useState(false);
  const hoverTimeoutRef = useRef(null);
  const modalRef = useRef(null);

  const handleMouseEnter = (imgSrc) => {
    // cancel any pending close
    if (hoverTimeoutRef.current) {
      clearTimeout(hoverTimeoutRef.current);
      hoverTimeoutRef.current = null;
    }

    // if modal already open, animate close-open for quick swap
    if (isOpen) {
      setClosing(true);
      setTimeout(() => {
        setIsOpen(false);
        setClosing(false);
        setTimeout(() => {
          setSelectedImage(imgSrc);
          setIsOpen(true);
        }, 50);
      }, 200);
    } else {
      setSelectedImage(imgSrc);
      setIsOpen(true);
    }
  };

  const handleMouseLeave = () => {
    // delay close slightly so moving between thumbnail -> modal doesn't close immediately
    hoverTimeoutRef.current = setTimeout(() => {
      setClosing(true);
      setTimeout(() => {
        setIsOpen(false);
        setSelectedImage(null);
        setClosing(false);
      }, 200);
    }, 250);
  };

  const handleModalEnter = () => {
    if (hoverTimeoutRef.current) {
      clearTimeout(hoverTimeoutRef.current);
      hoverTimeoutRef.current = null;
    }
  };

  const handleModalLeave = () => {
    handleMouseLeave();
  };

  // click outside to close
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (modalRef.current && !modalRef.current.contains(event.target)) {
        setClosing(true);
        setTimeout(() => {
          setIsOpen(false);
          setSelectedImage(null);
          setClosing(false);
        }, 200);
      }
    };

    if (isOpen) {
      document.addEventListener("mousedown", handleClickOutside);
      document.addEventListener("touchstart", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("touchstart", handleClickOutside);
    };
  }, [isOpen]);

  // Helper: render one Swiper (keeps sections DRY)
  const renderSwiper = (slidesArray) => (
    <Swiper
      modules={[Navigation, Pagination]}
      slidesPerView={5.65}
      spaceBetween={24}
      navigation={{
        prevEl: prevRef.current,
        nextEl: nextRef.current,
      }}
      pagination={{
        el: paginationRef.current,
        clickable: true,
      }}
      breakpoints={{
        0: { slidesPerView: 1.35 },
        768: { slidesPerView: 3.65 },
        1025: { slidesPerView: 4.65 },
        1450: { slidesPerView: 5.65 },
      }}
      onBeforeInit={(swiper) => {
        swiper.params.navigation.prevEl = prevRef.current;
        swiper.params.navigation.nextEl = nextRef.current;
        swiper.params.pagination.el = paginationRef.current;
      }}
    >
      {slidesArray.map((imgSrc, index) => (
        <SwiperSlide key={index}>
          <div
            className="img-box open-modal"
            onMouseEnter={() => handleMouseEnter(imgSrc)}
            onMouseLeave={handleMouseLeave}
          >
            <img src={imgSrc} alt={`template-${index}`} className="inner-pic" />
            <h6>Video name</h6>
          </div>
        </SwiperSlide>
      ))}
    </Swiper>
  );

  return (
    <>
      <section className="image-slider">
        <div className="container-fluid">
          <div className="row head-row">
            <div className="col-lg-6 col-9">
              <div className="headings">
                <h2>HEADING 01</h2>
                <p>Each template is valued at 250 credits.</p>
              </div>
            </div>
            <div className="col-lg-6 col-3">
              <div className="swiper-custom-nav">
                <button ref={prevRef} className="custom-button">
                  <svg width="16" height="27" viewBox="0 0 16 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M14 1.96141L2 13.4999L14 25.0383" stroke="#222222" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </button>
                <div ref={paginationRef} className="custom-pagination"></div>
                <button ref={nextRef} className="custom-button">
                  <svg width="16" height="27" viewBox="0 0 16 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M2 25L14 13.5L2 2" stroke="#222222" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </button>
              </div>
            </div>
          </div>

          <div className="row image-row">
            <div className="image-slider-outer login-home">
              {renderSwiper(templateImages)}
            </div>
          </div>
        </div>
      </section>

      {/* Section 2 */}
      <section className="image-slider pt-0">
        <div className="container-fluid">
          <div className="row head-row">
            <div className="col-lg-6 col-9">
              <div className="headings">
                <h2>HEADING 02</h2>
                <p>Each template is valued at 400 credits.</p>
              </div>
            </div>
            <div className="col-lg-6 col-3">
              <div className="swiper-custom-nav">
                <button ref={prevRef} className="custom-button">
                  <svg width="16" height="27" viewBox="0 0 16 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M14 1.96141L2 13.4999L14 25.0383" stroke="#222222" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </button>
                <div ref={paginationRef} className="custom-pagination"></div>
                <button ref={nextRef} className="custom-button">
                  <svg width="16" height="27" viewBox="0 0 16 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M2 25L14 13.5L2 2" stroke="#222222" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </button>
              </div>
            </div>
          </div>

          <div className="row image-row">
            <div className="image-slider-outer login-home">
              {renderSwiper(templateImages)}
            </div>
          </div>
        </div>
      </section>

      {/* Section 3 */}
      <section className="image-slider pt-0">
        <div className="container-fluid">
          <div className="row head-row">
            <div className="col-lg-6 col-9">
              <div className="headings">
                <h2>HEADING 03</h2>
                <p>Each template is valued at 600 credits.</p>
              </div>
            </div>
            <div className="col-lg-6 col-3">
              <div className="swiper-custom-nav">
                <button ref={prevRef} className="custom-button">
                  <svg width="16" height="27" viewBox="0 0 16 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M14 1.96141L2 13.4999L14 25.0383" stroke="#222222" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </button>
                <div ref={paginationRef} className="custom-pagination"></div>
                <button ref={nextRef} className="custom-button">
                  <svg width="16" height="27" viewBox="0 0 16 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M2 25L14 13.5L2 2" stroke="#222222" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </button>
              </div>
            </div>
          </div>

          <div className="row image-row">
            <div className="image-slider-outer login-home">
              {renderSwiper(templateImages)}
            </div>
          </div>
        </div>
      </section>

      {/* Section 4 */}
      <section className="image-slider pt-0">
        <div className="container-fluid">
          <div className="row head-row">
            <div className="col-lg-6 col-9">
              <div className="headings">
                <h2>HEADING 04</h2>
                <p>Each template is valued at 250 credits.</p>
              </div>
            </div>
            <div className="col-lg-6 col-3">
              <div className="swiper-custom-nav">
                <button ref={prevRef} className="custom-button">
                  <svg width="16" height="27" viewBox="0 0 16 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M14 1.96141L2 13.4999L14 25.0383" stroke="#222222" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </button>
                <div ref={paginationRef} className="custom-pagination"></div>
                <button ref={nextRef} className="custom-button">
                  <svg width="16" height="27" viewBox="0 0 16 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M2 25L14 13.5L2 2" stroke="#222222" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </button>
              </div>
            </div>
          </div>

          <div className="row image-row">
            <div className="image-slider-outer login-home">
              {renderSwiper(templateImages)}
            </div>
          </div>
        </div>
      </section>

      {/* Section 5 */}
      <section className="image-slider pt-0">
        <div className="container-fluid">
          <div className="row head-row">
            <div className="col-lg-6 col-9">
              <div className="headings">
                <h2>HEADING 05</h2>
                <p>Each template is valued at 600 credits.</p>
              </div>
            </div>
            <div className="col-lg-6 col-3">
              <div className="swiper-custom-nav">
                <button ref={prevRef} className="custom-button">
                  <svg width="16" height="27" viewBox="0 0 16 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M14 1.96141L2 13.4999L14 25.0383" stroke="#222222" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </button>
                <div ref={paginationRef} className="custom-pagination"></div>
                <button ref={nextRef} className="custom-button">
                  <svg width="16" height="27" viewBox="0 0 16 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M2 25L14 13.5L2 2" stroke="#222222" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </button>
              </div>
            </div>
          </div>

          <div className="row image-row">
            <div className="image-slider-outer login-home">
              {renderSwiper(templateImages)}
            </div>
          </div>
        </div>
      </section>

      {/* Modal */}
      {isOpen && (
        <div
          className={`template-modal ${closing ? "closing" : "opening"}`}
          onMouseEnter={handleModalEnter}
          onMouseLeave={handleModalLeave}
        >
          <div className="modal-content" ref={modalRef}>
            <div className="template-modal-outer">
              <div className="template-modal-img">
                <img src={selectedImage} alt="Selected Template" />
                <h2>Video name</h2>
              </div>
              <div className="template-modal-text">
                <p>
                  Description Eg: This video template showcases sleek sunglasses against a dark background, highlighting their design with smooth transitions and a final reveal.
                </p>
                <h5 className="list-heading">Things you can change</h5>
                <ul>
                  <li>
                    <img src={NotepadIcon} alt="NotepadIcon" />
                    <span>Product & Ingredients</span>
                  </li>
                  <li>
                    <img src={NotepadIcon} alt="NotepadIcon" />
                    <span>Background / Colors</span>
                  </li>
                  <li>
                    <img src={NotepadIcon} alt="NotepadIcon" />
                    <span>Text</span>
                  </li>
                </ul>
                <h6 className="desc-heading">Available aspect ratio</h6>
                <p className="aspect-desc">
                  1:1 (1080x1080), 9:16 (1080x1920), 16:9 (1920x1080), 4:5 (1080x1350)
                </p>
                <div className="text-end">
                  <Link to={""} className="btn btn-primary">
                    View details
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default Template_Slider;
