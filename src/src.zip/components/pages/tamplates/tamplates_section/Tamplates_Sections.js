// import React, { useRef, useState } from "react";
// import { Swiper, SwiperSlide } from "swiper/react";
// import { Navigation, Pagination } from "swiper/modules";
// import "swiper/css";
// import "swiper/css/navigation";
// import "swiper/css/pagination";
// import tamplates from "../../../../assets/images/tamplates.png";
// import NotepadIcon from "../../../../assets/images/notepad.svg";
// import { Link } from "react-router-dom";

// // Simulate 18 template images
// const templateImages = Array(18).fill(tamplates);

// const Tamplates_Sections = () => {
//   const prevRef = useRef(null);
//   const nextRef = useRef(null);
//   const paginationRef = useRef(null);
//   const [isOpen, setIsOpen] = useState(false);
//   const [selectedImage, setSelectedImage] = useState(null);

//   const handleOpen = (imgSrc) => {
//     setSelectedImage(imgSrc);
//     setIsOpen(true);
//   };

//   const handleClose = () => {
//     setIsOpen(false);
//     setSelectedImage(null);
//   };

//   // Group images into columns of 3 (for 3 rows per slide)
//   const groupedSlides = Array.from({
//     length: Math.ceil(templateImages.length / 3),
//   }).map((_, colIndex) =>
//     templateImages.slice(colIndex * 3, colIndex * 3 + 3)
//   );

//   return (
//     <section className="image-slider">
//       <div className="container-fluid">
//         <div className="section-heading">
//           <h2>
//             <b>Want to see more?</b> <span>Login</span> to view all templates
//           </h2>
//         </div>

//         <div className="row head-row">
//           <div className="col-lg-6 col-9">
//             <div className="headings">
//               <h2>Custom Lighting & Unboxing</h2>
//               <p>
//                 Create custom 3D ads that are as unique as your brand with
//                 Polycrafts.
//               </p>


//             </div>
//           </div>
//           <div className="col-lg-6 col-3">
//             {/* Custom Arrows */}
//             <div className="swiper-custom-nav">
//               <button ref={prevRef} className="custom-button">
//                 <svg width="16" height="27" viewBox="0 0 16 27" fill="none" xmlns="http://www.w3.org/2000/svg">
//                   <path d="M14 1.96141L2 13.4999L14 25.0383" stroke="#222222" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
//                 </svg>

//               </button>
//               {/* Custom Dots */}
//               <div ref={paginationRef} className="custom-pagination"></div>
//               <button ref={nextRef} className="custom-button">
//                 <svg width="16" height="27" viewBox="0 0 16 27" fill="none" xmlns="http://www.w3.org/2000/svg">
//                   <path d="M2 25L14 13.5L2 2" stroke="#222222" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
//                 </svg>

//               </button>
//             </div>


//           </div>
//         </div>

//         <div className="row image-row">
//           <div className="image-slider-outer">
//             <Swiper
//               modules={[Navigation, Pagination]}
//               slidesPerView={5.65}
//               spaceBetween={24}
//               navigation={{
//                 prevEl: prevRef.current,
//                 nextEl: nextRef.current,
//               }}
//               pagination={{
//                 el: paginationRef.current,
//                 clickable: true,
//               }}
//               breakpoints={{
//                 0: {
//                   slidesPerView: 1.35,
//                 },
//                 768: {
//                   slidesPerView: 3.65,
//                 },
//                 1025: {
//                   slidesPerView: 4.65,
//                 },
//                 1450: {
//                   slidesPerView: 5.65,
//                 },
//               }}
//               onBeforeInit={(swiper) => {
//                 swiper.params.navigation.prevEl = prevRef.current;
//                 swiper.params.navigation.nextEl = nextRef.current;
//                 swiper.params.pagination.el = paginationRef.current;
//               }}
//             >
//               {groupedSlides.map((group, colIndex) => (
//                 <SwiperSlide key={colIndex}>
//                   <div className="multi-row-column">
//                     {group.map((imgSrc, rowIdx) => (
//                       <div
//                         key={rowIdx}
//                         className="img-box open-modal"
//                         onClick={() => handleOpen(imgSrc)}
//                       >
//                         <img
//                           src={imgSrc}
//                           alt={`template-${colIndex * 3 + rowIdx}`}
//                           className="inner-pic"
//                         />
//                       </div>
//                     ))}
//                   </div>
//                 </SwiperSlide>
//               ))}
//             </Swiper>
//           </div>
//         </div>
//       </div>

//       {/* Modal */}
//       {isOpen && (
//         <div className="template-modal" onClick={handleClose}>
//           <div className="modal-content">
//             <div className="template-modal-outer">
//               <div className="template-modal-img">
//                 <img src={selectedImage} alt="Selected Template" />
//                 <h2>Video name</h2>
//               </div>
//               <div className="template-modal-text">
//                 <p>
//                   Description Eg: This video template showcases sleek sunglasses against a dark background, highlighting their design with smooth transitions and a final reveal. It's perfect
//                 </p>
//                 <h5 className="list-heading">Things you can change</h5>
//                 <ul>
//                   <li>
//                     <img src={NotepadIcon} alt="NotepadIcon" />
//                     <span>
//                       Product & Ingredients
//                     </span>
//                   </li>
//                   <li>
//                     <img src={NotepadIcon} alt="NotepadIcon" />
//                     <span>
//                       Background / Colors
//                     </span>
//                   </li>
//                   <li>
//                     <img src={NotepadIcon} alt="NotepadIcon" />
//                     <span>
//                       Text
//                     </span>
//                   </li>
//                 </ul>
//                 <h6 className="desc-heading">
//                   Available aspect ratio
//                 </h6>
//                 <p className="aspect-desc">
//                   1:1 (1080x1080), 9:16 (1080x1920), 16:9 (1920x1080), 4:5 (1080x1350)
//                 </p>
//                 <div className="text-end">
//                   <Link to={''} className="btn btn-primary">
//                     View details
//                   </Link>
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//       )}
//     </section>
//   );
// };

// export default Tamplates_Sections;

import React, { useRef, useState, useEffect } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation, Pagination } from "swiper/modules";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import tamplates from "../../../../assets/images/tamplates.png";
import NotepadIcon from "../../../../assets/images/notepad.svg";
import { Link } from "react-router-dom";
import "../../../../assets/css/custom.css";

// Simulate 18 template images
const templateImages = Array(18).fill(tamplates);

const Tamplates_Sections = () => {
  const prevRef = useRef(null);
  const nextRef = useRef(null);
  const paginationRef = useRef(null);
  const [isOpen, setIsOpen] = useState(false);
  const [selectedImage, setSelectedImage] = useState(null);
  const [closing, setClosing] = useState(false);
  const hoverTimeoutRef = useRef(null);
  const modalRef = useRef(null);

  const handleMouseEnter = (imgSrc) => {
    // Clear any pending close timeouts
    if (hoverTimeoutRef.current) {
      clearTimeout(hoverTimeoutRef.current);
      hoverTimeoutRef.current = null;
    }
    
    // If modal is already open, close it first with animation
    if (isOpen) {
      setClosing(true);
      setTimeout(() => {
        setIsOpen(false);
        setClosing(false);
        // Open new modal after a brief delay
        setTimeout(() => {
          setSelectedImage(imgSrc);
          setIsOpen(true);
        }, 50);
      }, 300);
    } else {
      setSelectedImage(imgSrc);
      setIsOpen(true);
    }
  };

  const handleMouseLeave = () => {
    // Set timeout to close modal after a short delay
    hoverTimeoutRef.current = setTimeout(() => {
      setClosing(true);
      setTimeout(() => {
        setIsOpen(false);
        setSelectedImage(null);
        setClosing(false);
      }, 300);
    }, 300);
  };

  const handleModalEnter = () => {
    // Cancel close timeout if user moves to modal
    if (hoverTimeoutRef.current) {
      clearTimeout(hoverTimeoutRef.current);
      hoverTimeoutRef.current = null;
    }
  };

  const handleModalLeave = () => {
    // Close modal when leaving modal area
    handleMouseLeave();
  };

  // Close modal when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (modalRef.current && !modalRef.current.contains(event.target)) {
        setClosing(true);
        setTimeout(() => {
          setIsOpen(false);
          setSelectedImage(null);
          setClosing(false);
        }, 300);
      }
    };

    if (isOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [isOpen]);

  // Group images into columns of 3 (for 3 rows per slide)
  const groupedSlides = Array.from({
    length: Math.ceil(templateImages.length / 3),
  }).map((_, colIndex) =>
    templateImages.slice(colIndex * 3, colIndex * 3 + 3)
  );

  return (
    <section className="image-slider">
      <div className="container-fluid">
        <div className="section-heading">
          <h2>
            <b>Want to see more?</b> <span>Login</span> to view all templates
          </h2>
        </div>

        <div className="row head-row">
          <div className="col-lg-6 col-9">
            <div className="headings">
              <h2>Custom Lighting & Unboxing</h2>
              <p>
                Create custom 3D ads that are as unique as your brand with
                Polycrafts.
              </p>
            </div>
          </div>
          <div className="col-lg-6 col-3">
            {/* Custom Arrows */}
            <div className="swiper-custom-nav">
              <button ref={prevRef} className="custom-button">
                <svg width="16" height="27" viewBox="0 0 16 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M14 1.96141L2 13.4999L14 25.0383" stroke="#222222" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </button>
              {/* Custom Dots */}
              <div ref={paginationRef} className="custom-pagination"></div>
              <button ref={nextRef} className="custom-button">
                <svg width="16" height="27" viewBox="0 0 16 27" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M2 25L14 13.5L2 2" stroke="#222222" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </button>
            </div>
          </div>
        </div>

        <div className="row image-row">
          <div className="image-slider-outer">
            <Swiper
              modules={[Navigation, Pagination]}
              slidesPerView={5.65}
              spaceBetween={24}
              navigation={{
                prevEl: prevRef.current,
                nextEl: nextRef.current,
              }}
              pagination={{
                el: paginationRef.current,
                clickable: true,
              }}
              breakpoints={{
                0: {
                  slidesPerView: 1.35,
                },
                768: {
                  slidesPerView: 3.65,
                },
                1025: {
                  slidesPerView: 4.65,
                },
                1450: {
                  slidesPerView: 5.65,
                },
              }}
              onBeforeInit={(swiper) => {
                swiper.params.navigation.prevEl = prevRef.current;
                swiper.params.navigation.nextEl = nextRef.current;
                swiper.params.pagination.el = paginationRef.current;
              }}
            >
              {groupedSlides.map((group, colIndex) => (
                <SwiperSlide key={colIndex}>
                  <div className="multi-row-column">
                    {group.map((imgSrc, rowIdx) => (
                      <div
                        key={rowIdx}
                        className="img-box open-modal"
                        onMouseEnter={() => handleMouseEnter(imgSrc)}
                        onMouseLeave={handleMouseLeave}
                      >
                        <img
                          src={imgSrc}
                          alt={`template-${colIndex * 3 + rowIdx}`}
                          className="inner-pic"
                        />
                      </div>
                    ))}
                  </div>
                </SwiperSlide>
              ))}
            </Swiper>
          </div>
        </div>
      </div>

      {/* Modal */}
      {isOpen && (
        <div 
          className={`template-modal ${closing ? 'closing' : 'opening'}`}
          onMouseEnter={handleModalEnter}
          onMouseLeave={handleModalLeave}
        >
          <div className="modal-content" ref={modalRef}>
            <div className="template-modal-outer">
              <div className="template-modal-img">
                <img src={selectedImage} alt="Selected Template" />
                <h2>Video name</h2>
              </div>
              <div className="template-modal-text">
                <p>
                  Description Eg: This video template showcases sleek sunglasses against a dark background, highlighting their design with smooth transitions and a final reveal. It's perfect
                </p>
                <h5 className="list-heading">Things you can change</h5>
                <ul>
                  <li>
                    <img src={NotepadIcon} alt="NotepadIcon" />
                    <span>
                      Product & Ingredients
                    </span>
                  </li>
                  <li>
                    <img src={NotepadIcon} alt="NotepadIcon" />
                    <span>
                      Background / Colors
                    </span>
                  </li>
                  <li>
                    <img src={NotepadIcon} alt="NotepadIcon" />
                    <span>
                      Text
                    </span>
                  </li>
                </ul>
                <h6 className="desc-heading">
                  Available aspect ratio
                </h6>
                <p className="aspect-desc">
                  1:1 (1080x1080), 9:16 (1080x1920), 16:9 (1920x1080), 4:5 (1080x1350)
                </p>
                <div className="text-end">
                  <Link to={''} className="btn btn-primary">
                    View details
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

export default Tamplates_Sections;