import React, { useState } from 'react'
import Header from '../../common/header/Header'
import { Link } from 'react-router-dom'
import Reach_Us_Form from '../../common/reach_out_form/Reach_Us_Form'
import Book_Call from '../../common/book_call_popup/Book_Call'
import ReachStartImg from "../../../assets/images/about-start-img.png";
import SearchIcon from "../../../assets/images/search-icon.svg";
import Accordion from 'react-bootstrap/Accordion';

const FAQ = () => {

  const [Bookshow, setBookShow] = useState(false);

  const handleBookShow = () => setBookShow(true);
  const handleBookClose = () => setBookShow(false);

  return (
    <>
      <main className="faq-page">

        {/* ===== HEADER ===== */}
        <Header />

        <section className='about-banner px-85'>
          <div className="container-fluid">
            <div className='row banner-row'>
              <div className="col-about-banner">
                <div className='page-heading'>
                  <h1>
                    Frequently Asked Questions
                  </h1>
                  <div className='faq-search-form'>
                      <form>
                        <img src={SearchIcon} alt="SearchIcon" />
                        <input type="text" className='form-control' placeholder='Search your questions, answer etc...'/>
                      </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className='faq-question px-85'>
          <div className="container-fluid">
            <div className='row faq-row'>
              <div className='col-faq-tabings'>
                <ul>
                  <li>
                    <button className='tab-btn active'>
                      About Polycrafts
                    </button>
                  </li>
                  <li>
                    <button className='tab-btn'>
                      Process
                    </button>
                  </li>
                  <li>
                    <button className='tab-btn'>
                      Membership
                    </button>
                  </li>
                  <li>
                    <button className='tab-btn'>
                      Pricing
                    </button>
                  </li>
                </ul>
              </div>
              <div className='col-faq-accordin'>
                <Accordion defaultActiveKey="0">
                  <Accordion.Item eventKey="0">
                    <Accordion.Header>What is Polycrafts?</Accordion.Header>
                    <Accordion.Body>
                      <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                        eiusmod tempor incididunt ut labore et dolore magna aliqua.
                      </p>
                      <p>
                        Ut enim ad
                        minim veniam, quis nostrud exercitation ullamco laboris nisi ut
                        aliquip ex ea commodo consequat. Duis aute irure dolor in
                        reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
                        pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
                        culpa qui officia deserunt mollit anim id est laborum.
                      </p>
                    </Accordion.Body>
                  </Accordion.Item>
                  <Accordion.Item eventKey="1">
                    <Accordion.Header>Question #2</Accordion.Header>
                    <Accordion.Body>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                      eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
                      minim veniam, quis nostrud exercitation ullamco laboris nisi ut
                      aliquip ex ea commodo consequat. Duis aute irure dolor in
                      reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
                      pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
                      culpa qui officia deserunt mollit anim id est laborum.
                    </Accordion.Body>
                  </Accordion.Item>
                  <Accordion.Item eventKey="2">
                    <Accordion.Header>Question #3</Accordion.Header>
                    <Accordion.Body>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                      eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
                      minim veniam, quis nostrud exercitation ullamco laboris nisi ut
                      aliquip ex ea commodo consequat. Duis aute irure dolor in
                      reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
                      pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
                      culpa qui officia deserunt mollit anim id est laborum.
                    </Accordion.Body>
                  </Accordion.Item>
                  <Accordion.Item eventKey="3">
                    <Accordion.Header>Question #4</Accordion.Header>
                    <Accordion.Body>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                      eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
                      minim veniam, quis nostrud exercitation ullamco laboris nisi ut
                      aliquip ex ea commodo consequat. Duis aute irure dolor in
                      reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
                      pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
                      culpa qui officia deserunt mollit anim id est laborum.
                    </Accordion.Body>
                  </Accordion.Item>
                </Accordion>
              </div>
            </div>
          </div>
        </section>

        <section className="px-85">
          <div className="container-fluid">
            <div className='ready-start-bg'>
              <div className='reach-start-row'>
                <div className='reach-start-text'>
                  <h2 className='gradient-text'>Ready to Start Creating?</h2>
                  <p>Sign up for a free account or explore our membership plans to unlock the full Poly Craft experience.</p>
                  <Link to='#' className='btn btn-primary'>
                    Let's Start
                  </Link>
                </div>
                <div className='reach-start-img'>
                  <img src={ReachStartImg} alt="ReachStartImg" />
                </div>
              </div>

            </div>
          </div>
        </section>

        <section className='book-call-btn'>
          <div className="container-fluid">
            <div className='col-book-btn about-us'>
              <button className='btn btn-primary' onClick={handleBookShow}>
                Book A Call
              </button>
              <Book_Call Bookshow={Bookshow} handleBookClose={handleBookClose} />
            </div>
          </div>
        </section>

        <Reach_Us_Form />

      </main>


    </>
  )
}

export default FAQ