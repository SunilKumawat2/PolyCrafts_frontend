import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';
import { useState } from 'react';
import { Dropdown } from 'react-bootstrap';



const Book_Call = ({ Bookshow, handleBookClose }) => {



    return (
        <>
            <Modal size='xl' show={Bookshow} onHide={handleBookClose}>
                <Modal.Header closeButton>
                    <Modal.Title>Book a free consultation</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <div className='book-call-row'>
                        <div className='col-left-inputs'>
                            <form>
                                <div className='row inner-row'>
                                    {/* <div className='col-12'>
                                        <div className='profile-id'>
                                            <span>Book a 15 min call</span>
                                        </div>
                                    </div> */}
                                    <div className='col-12'>
                                        <div className='form-group'>
                                            <label><span className='text-danger'>*</span>Full Name</label>
                                            <input type="text" className='form-control' placeholder='Enter additional details' />
                                        </div>
                                    </div>
                                    <div className='col-12'>
                                        <div className='form-group'>
                                            <label><span className='text-danger'>*</span>Email</label>
                                            <input type="email" className='form-control' placeholder='Enter additional details' />
                                        </div>
                                    </div>
                                    <div className='col-12'>
                                        <div className='form-group'>
                                            <label>Company</label>
                                            <input type="text" className='form-control' placeholder='Enter additional details' />
                                        </div>
                                    </div>
                                    <div className='col-12'>
                                        <div className='form-group'>
                                            <label>Phone no</label>
                                            <input type="tel" className='form-control' placeholder='Enter additional details' />
                                        </div>
                                    </div>
                                    <div className='col-12'>
                                        <div className='form-group'>
                                            <label className='me-2'>TIME: </label>
                                            <Dropdown className='time-dropdown'>
                                                <Dropdown.Toggle id="dropdown-basic">
                                                    Select Time
                                                </Dropdown.Toggle>
                                                <Dropdown.Menu>
                                                        <Dropdown.Item>01:00 PM - 01:30 PM</Dropdown.Item>
                                                        <Dropdown.Item>01:30 PM - 02:00 PM</Dropdown.Item>
                                                        <Dropdown.Item>02:00 PM - 02:30 PM</Dropdown.Item>
                                                        <Dropdown.Item>02:30 PM - 03:00 PM</Dropdown.Item>
                                                        <Dropdown.Item>03:00 PM - 03:30 PM</Dropdown.Item>
                                                        <Dropdown.Item>03:30 PM - 04:00 PM</Dropdown.Item>
                                                        <Dropdown.Item>04:00 PM - 04:30 PM</Dropdown.Item>
                                                        <Dropdown.Item>04:30 PM - 05:00 PM</Dropdown.Item>
                                                        <Dropdown.Item>05:00 PM - 05:30 PM</Dropdown.Item>
                                                        <Dropdown.Item>05:30 PM - 06:00 PM</Dropdown.Item>
                                                </Dropdown.Menu>
                                            </Dropdown>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div className='col-right-calender'>
                            <Calendar />
                        </div>
                    </div>
                </Modal.Body>
                <Modal.Footer className='justify-content-center'>
                    <Button variant="primary" onClick={() => alert('Saving changes...')}>
                        Book Call
                    </Button>
                </Modal.Footer>
            </Modal>
        </>
    );
};

export default Book_Call;
