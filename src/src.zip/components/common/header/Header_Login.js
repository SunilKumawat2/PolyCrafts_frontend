import React from 'react'
import Logo from "../../../assets/images/LOGO.svg";
import DpImg from "../../../assets/images/dp-img.jpg";
import plusImg from "../../../assets/images/plus-wh.svg";
import userId from "../../../assets/images/user-id.svg";
import change_password from "../../../assets/images/password.svg";
import download from "../../../assets/images/download.svg";
import cart from "../../../assets/images/cart.svg";
import heart from "../../../assets/images/heart.svg";
import uploadIcon from "../../../assets/images/upload-products.svg";
import pencilIcon from "../../../assets/images/pencil.svg";
import ReelIcon from "../../../assets/images/pricing.svg";
import LogoutId from "../../../assets/images/logout.svg";
import { Button, Container, Dropdown, Nav, Navbar } from 'react-bootstrap';
import { Link, useLocation } from 'react-router-dom';
import { User_Logout } from '../../../api/auth/Auth';

const Header_Login = () => {


  let base_url = process.env.REACT_APP_BASE_URL;

  const location = useLocation();

  const handleLogout = async () => {
    const confirmLogout = window.confirm("Are you sure you want to log out?");
    if (!confirmLogout) return; // ❌ stop if user cancels

    try {
      const response = await User_Logout();
      console.log("Logout response:", response);

      if (response?.data?.status === true) {
        // ✅ Clear token & refresh
        localStorage.removeItem("polycarft_user_token");
        window.location.reload(); // refresh to re-render routes
      } else {
        alert(response?.data?.message || "Logout failed.");
      }
    } catch (error) {
      console.error("Logout error:", error);
      alert("Something went wrong while logging out.");
    }
  };

  return (
    <>
      <header className="main-header px-85">
        <Navbar expand="lg" className="header-inner p-0">
          <Container fluid>
            <div className='logo-toggler'>
              <Navbar.Toggle aria-controls="basic-navbar-nav" />
              <Link to={`${base_url}`} className='nav-logo'>
                <img src={Logo} alt="Logo" className="main-logo" />
              </Link>
            </div>
            <Navbar.Collapse id="basic-navbar-nav">
              <div className='navbar-links-outer'>
                <Nav className="navbar-links left-links">
                  <Nav.Link className={`${location.pathname === `${base_url}pricing` ? "active" : ""}`} href={``}>
                    <img src={ReelIcon} alt="download" /> <span>Templates</span>
                  </Nav.Link>
                  <Nav.Link className={`${location.pathname === `${base_url}about` ? "active" : ""}`} href={``}>
                    <img src={uploadIcon} alt="download" /> <span>Upload Products</span>
                  </Nav.Link>


                </Nav>
                <Nav className="navbar-links">
                  <Nav.Link className={`${location.pathname === `${base_url}pricing` ? "active" : ""}`} href={``}>
                    <img src={pencilIcon} alt="download" /> <span>Poly Editor</span>
                  </Nav.Link>
                  <Nav.Link className={`${location.pathname === `${base_url}services` ? "active" : ""}`} href={``}>
                    <img src={ReelIcon} alt="download" /> <span>Pricing</span>
                  </Nav.Link>
                  <Nav.Link className={`${location.pathname === `${base_url}faq` ? "active" : ""}`} href={``}>
                    <img src={ReelIcon} alt="download" /> <span>My Orders</span>
                  </Nav.Link>
                  <div className='store-links'>
                    <Link>
                      <img src={download} alt="download" />
                    </Link>
                    <Link>
                      <img src={heart} alt="heart" />
                    </Link>
                    <Link>
                      <img src={cart} alt="cart" />
                    </Link>
                  </div>


                </Nav>

              </div>

            </Navbar.Collapse>
            <Dropdown className='profile-dropdown'>
              <Dropdown.Toggle variant='success'>
                <div className='info-box'>
                  <div className='text-end'>
                    <h6>Credits</h6>
                    <span className='amt'>100</span>
                  </div>
                  <img src={DpImg} alt="DpImg" />
                </div>
              </Dropdown.Toggle>

              <Dropdown.Menu align="end">
                <div className='profile-dropdown-menu'>
                  <div className='top-image'>
                    <img src={DpImg} alt="DpImg" />
                    <h6 className='name'>Quang Nguyen</h6>
                  </div>
                  <div className='credits-avail'>
                    <h6>Credit available</h6>
                    <div className='inner-info'>
                      <h4>100</h4>
                      <Link to={``} className='btn btn-primary'>
                        <img src={plusImg} alt="plusImg" />
                        <span> Add </span>
                      </Link>
                    </div>
                  </div>
                  <div className='profile-links'>
                    <Link to={`${base_url}user-profile`}>
                      <img src={userId} alt="userId" />
                      <span>My Profile</span>
                    </Link>
                    <Link to={`${base_url}change-password`}>
                      <img src={change_password} alt="change_password" style={{width:"25px"}}/>
                      <span>Change Password</span>
                    </Link>
                    <div onClick={handleLogout}>
                      <Link to={`${base_url}`}>
                        <img src={LogoutId} alt="LogoutId" />
                        <span>Log out</span>
                      </Link>
                    </div>

                  </div>
                </div>
              </Dropdown.Menu>
            </Dropdown>
          </Container>
        </Navbar>

      </header>


    </>
  )
}

export default Header_Login