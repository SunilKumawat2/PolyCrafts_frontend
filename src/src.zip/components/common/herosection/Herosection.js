import React from 'react'
import { Link } from 'react-router-dom'
import WorksVideo from "../../../../src/assets/images/HomePage.mp4";
import HeroVideo from "../../../../src/assets/images/placeholder-video.mp4";



const Herosection = () => {
  return (
    <>
      <section className='hero-section px-85'>
        <div className='container-fluid'>
          <div className='row hero-row'>
            <div className='col-hero-text'>
              <div className='hero-text'>
                <h1>Level up your brand with Polycrafts 3D video ads</h1>
                <p>Create custom 3D ads that are as unique as your brand with Polycrafts. For affordable plans that suit every budget, we deliver high-quality ads that boost your brand visibility.</p>
                <Link to='#' className='btn btn-primary'>
                  Buy credits
                </Link>
                <span className='mini-msg'>Get 50 free credits when you sign up for your first template!</span>
              </div>
            </div>
            <div className='col-video-text'>
              <div className='hero-video'>
                <video controls muted>
                  <source src={HeroVideo} />
                </video>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section className='home-works-video px-85'>
        <div className="container-fluid">
          <div className='video-outer'>
            <video autoPlay loop muted playsInline>
              <source src={WorksVideo} />
            </video>
          </div>
        </div>
      </section>
    </>
  )
}

export default Herosection
