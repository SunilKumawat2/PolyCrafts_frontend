import React from 'react'
import Logo from "../../../assets/images/LOGO.svg";
import { Link } from 'react-router-dom';

const Footer = () => {
  const footerLinks = [
    { text: "About Us", href: "#" },
    { text: "Pricing", href: "#" },
    { text: "Services", href: "#" },
    { text: "FAQ's", href: "#" },
  ];

  return (
    <footer>
      <section className='footer-top'>
        <div className='container-fluid'>
          <div className='footer-top-menus'>
            <div className='footer-logo'>
              <Link to='#' href="#home">
                <img src={Logo} alt="Logo" className="main-logo" />
              </Link>
            </div>
            <div className='menu-links'>
              <ul>
                <li>
                  <Link className='footer-link' to={''}> About Us </Link>
                </li>
                <li>
                  <Link className='footer-link' to={''}> Pricing </Link>
                </li>
                <li>
                  <Link className='footer-link' to={''}> Services </Link>
                </li>
                <li>
                  <Link className='footer-link' to={''}> FAQ’s </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className='copyright-text'>
<p>PolycraftsStudio® | Copyright 2025 | <Link to={''}>Terms of service</Link> | <Link to={''}>Privacy policy</Link></p>
          </div>
        </div>
      </section>
    </footer>
  )
}

export default Footer
